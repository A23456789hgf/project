<?php

namespace App\Http\Controllers\Approval;

use App\Enums\ApprovalPhase;
use App\Enums\ProjectStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\Approval\RespondConsultationRequest;
use App\Models\InternalEntity;
use App\Models\Project;
use App\Models\ProjectApproval;
use App\Models\ProjectReferral;
use App\Services\ApprovalService;
use App\Services\EntityHierarchyService;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;

class ApprovalCenterController extends Controller
{
    protected ApprovalService $approvalService;

    protected EntityHierarchyService $entityHierarchyService;

    public function __construct(
        ApprovalService $approvalService,
        EntityHierarchyService $entityHierarchyService
    ) {
        $this->approvalService = $approvalService;
        $this->entityHierarchyService = $entityHierarchyService;
    }

    /**
     * مركز المراجعة والاعتمادات.
     *
     * قواعد العرض:
     *
     * 1) مدير النظام:
     *    - يرى جميع المشاريع بجميع حالاتها.
     *    - يرى المشروع حتى لو لم يبدأ مسار الموافقات.
     *    - يستطيع فتح التفاصيل والاطلاع على كامل السجل.
     *
     * 2) المستخدم العادي:
     *    - يرى المشروع فقط إذا كانت المرحلة النشطة الحالية موجهة إليه
     *      أو إلى جهته ومسموحاً له بتنفيذ الإجراء عليها.
     *    - بمجرد انتقال المشروع إلى المرحلة التالية وإلغاء is_active
     *      عن مرحلته السابقة، يختفي المشروع من قائمته تلقائياً.
     *    - إذا أعيد المشروع للمنشئ للمراجعة، يظهر للمنشئ/جهته فقط
     *      إلى أن يعاد إرساله.
     *
     * 3) كل مشروع يظهر كسجل واحد فقط.
     */
    public function index(Request $request)
    {
        $user = Auth::user();

        abort_unless($user, 403, 'Unauthorized');

        $userEntityId = (int) ($user->entity_id ?? 0);

        $isAdmin = method_exists($user, 'isAdmin')
            ? (bool) $user->isAdmin()
            : false;

        /*
        |--------------------------------------------------------------------------
        | المشاريع التي يملك المستخدم إجراءً فعلياً عليها الآن
        |--------------------------------------------------------------------------
        |
        | نبدأ بفلترة قاعدة البيانات حسب:
        | - المرحلة نشطة is_active = true
        | - حالتها pending
        | - المشروع في حالة Pending Approval
        | - الجهة هي جهة المستخدم
        | - الإسناد للمستخدم نفسه أو غير مخصص لمستخدم بعينه
        |
        | ثم نمرر النتائج على ApprovalService::canUserActOnStep()
        | حتى لا يظهر المشروع لمن لا يملك الصلاحية الفعلية.
        |
        */

        $actionableProjectIds = collect();

        if (! $isAdmin && $userEntityId > 0) {
            $candidateApprovals = ProjectApproval::query()
                ->with([
                    'project',
                    'entity',
                    'reviewedByUser',
                    'technicalReviewer',
                    'financialReviewer',
                ])
                ->where('is_active', true)
                ->where('status', 'pending')
                ->where('entity_id', $userEntityId)
                ->whereHas('project', function ($projectQuery) {
                    $projectQuery->where(
                        'status',
                        ProjectStatus::PendingApproval->value
                    );
                })
                ->where(function ($assignmentQuery) use ($user) {
                    /*
                     * المراجعة الفنية:
                     * - مسندة لهذا المستخدم، أو
                     * - غير مسندة لمستخدم محدد داخل الجهة.
                     */
                    $assignmentQuery
                        ->where(function ($technicalQuery) use ($user) {
                            $technicalQuery
                                ->where('phase', 'technical_review')
                                ->where(function ($reviewerQuery) use ($user) {
                                    $reviewerQuery
                                        ->where(
                                            'technical_reviewer_id',
                                            $user->id
                                        )
                                        ->orWhereNull(
                                            'technical_reviewer_id'
                                        );
                                });
                        })

                        /*
                         * المراجعة المالية.
                         */
                        ->orWhere(function ($financialQuery) use ($user) {
                            $financialQuery
                                ->where('phase', 'financial_review')
                                ->where(function ($reviewerQuery) use ($user) {
                                    $reviewerQuery
                                        ->where(
                                            'financial_reviewer_id',
                                            $user->id
                                        )
                                        ->orWhereNull(
                                            'financial_reviewer_id'
                                        );
                                });
                        })

                        /*
                         * بقية المراحل.
                         */
                        ->orWhere(function ($otherQuery) use ($user) {
                            $otherQuery
                                ->where(function ($phaseQuery) {
                                    $phaseQuery
                                        ->whereNotIn(
                                            'phase',
                                            [
                                                'technical_review',
                                                'financial_review',
                                            ]
                                        )
                                        ->orWhereNull('phase');
                                })
                                ->where(function ($assignedUserQuery) use ($user) {
                                    $assignedUserQuery
                                        ->where(
                                            'assigned_user_id',
                                            $user->id
                                        )
                                        ->orWhereNull(
                                            'assigned_user_id'
                                        );
                                });
                        });
                })
                ->get();

            /*
             * الفحص النهائي بواسطة الخدمة.
             *
             * هذا مهم حتى لا نعتمد فقط على entity_id / assigned_user_id،
             * بل أيضاً على منطق الصلاحيات الحقيقي الموجود في ApprovalService.
             */
            $actionableProjectIds = $candidateApprovals
                ->filter(function (ProjectApproval $approval) use ($user) {
                    return $this->approvalService->canUserActOnStep(
                        $user,
                        $approval
                    );
                })
                ->pluck('project_id')
                ->filter()
                ->unique()
                ->values();
        }

        /*
        |--------------------------------------------------------------------------
        | استعلام المشاريع
        |--------------------------------------------------------------------------
        */

        $projectsQuery = Project::query()
            ->with([
                'createdBy',
                'creatorEntity',
                'cost',

                /*
                 * نحمّل السلسلة لتحديد المرحلة الحالية المعروضة في index.
                 * وجودها هنا لا يعني أن المستخدم العادي يستطيع فتح التاريخ
                 * الكامل؛ حماية التاريخ الكامل تتم في show().
                 */
                'projectApprovals' => function ($query) {
                    $query
                        ->with([
                            'entity',
                            'reviewedByUser',
                            'technicalReviewer',
                            'financialReviewer',
                        ])
                        ->orderBy('step_order')
                        ->orderBy('id');
                },
            ]);

        /*
        |--------------------------------------------------------------------------
        | صلاحية نطاق العرض
        |--------------------------------------------------------------------------
        */

        if (! $isAdmin) {
            /*
             * المستخدم العادي:
             *
             * يرى فقط:
             * A) مشروعاً لديه عليه إجراء في المرحلة النشطة الحالية.
             * B) أو مشروعاً أعيد إليه/إلى جهته كمنشئ للمراجعة.
             *
             * لا يرى المشاريع السابقة التي انتهى دوره فيها.
             * لا يرى المشاريع المكتملة/المرفوضة/المعتمدة لمجرد أنه شارك فيها.
             */
            $projectsQuery->where(function ($projectScope) use (
                $actionableProjectIds,
                $user,
                $userEntityId
            ) {
                if ($actionableProjectIds->isNotEmpty()) {
                    $projectScope->whereIn(
                        'id',
                        $actionableProjectIds->all()
                    );
                } else {
                    /*
                     * نبدأ بشرط مستحيل ثم نضيف OR لحالة الإعادة للمنشئ.
                     * هذا يحافظ على شكل where-group الصحيح.
                     */
                    $projectScope->whereRaw('1 = 0');
                }

                /*
                 * المشروع المعاد للمنشئ:
                 * يصبح المنشئ هو صاحب المهمة الحالية إلى أن يعيد الإرسال.
                 */
                $projectScope->orWhere(function ($rolledBackQuery) use (
                    $user,
                    $userEntityId
                ) {
                    $rolledBackQuery
                        ->where('status', 'rolled_back_for_review')
                        ->where(function ($creatorQuery) use (
                            $user,
                            $userEntityId
                        ) {
                            $creatorQuery->where(
                                'created_by_user_id',
                                $user->id
                            );

                            if ($userEntityId > 0) {
                                $creatorQuery->orWhere(
                                    'creator_entity_id',
                                    $userEntityId
                                );
                            }
                        });
                });
            });
        }

        /*
         * المدير لا نضع عليه أي whereHas(projectApprovals)
         * حتى يرى كل المشاريع بكل حالاتها، بما فيها المشاريع التي
         * لم تدخل مسار الموافقات بعد.
         */

        /*
        |--------------------------------------------------------------------------
        | البحث
        |--------------------------------------------------------------------------
        */

        if ($request->filled('search')) {
            $search = trim(
                (string) $request->input('search')
            );

            $projectsQuery->where(function ($query) use ($search) {
                $query
                    ->where(
                        'project_name',
                        'like',
                        "%{$search}%"
                    )
                    ->orWhere(
                        'form_number',
                        'like',
                        "%{$search}%"
                    )
                    ->orWhere(
                        'id',
                        'like',
                        "%{$search}%"
                    );
            });
        }

        /*
        |--------------------------------------------------------------------------
        | فلتر الجهة - للمدير فقط
        |--------------------------------------------------------------------------
        |
        | موجود لدعم أي select entity_id في الواجهة.
        |
        */

        if (
            $isAdmin
            && $request->filled('entity_id')
        ) {
            $entityId = (int) $request->input('entity_id');

            $projectsQuery->where(function ($query) use ($entityId) {
                /*
                 * جهة إنشاء المشروع.
                 */
                $query->where(
                    'creator_entity_id',
                    $entityId
                )

                /*
                 * أو الجهة الموجودة في أي مرحلة موافقة.
                 */
                ->orWhereHas(
                    'projectApprovals',
                    function ($approvalQuery) use ($entityId) {
                        $approvalQuery->where(
                            'entity_id',
                            $entityId
                        );
                    }
                );
            });
        }

        /*
        |--------------------------------------------------------------------------
        | حالة المشروع
        |--------------------------------------------------------------------------
        */

        if ($request->filled('status')) {
            $status = $request->input('status');
            $projectsQuery->where('status', $status);
        }

        /*
        |--------------------------------------------------------------------------
        | المرحلة النشطة
        |--------------------------------------------------------------------------
        */

        if ($request->filled('phase')) {
            $phase = $request->input('phase');
            $projectsQuery->whereHas('projectApprovals', function ($approvalQuery) use ($phase) {
                $approvalQuery->where('phase', $phase)->where('is_active', true);
            });
        }

        /*
        |--------------------------------------------------------------------------
        | Pagination and Sorting
        |--------------------------------------------------------------------------
        |
        | Project هو أساس الاستعلام؛ لذلك المشروع يظهر مرة واحدة فقط.
        |
        */

        $sortBy = $request->input('sort_by', 'updated_at');
        if (! in_array($sortBy, ['updated_at', 'created_at', 'project_name', 'form_number', 'id'])) {
            $sortBy = 'updated_at';
        }

        $sortDirection = $request->input('sort_direction', 'desc') === 'asc' ? 'asc' : 'desc';
        
        $perPage = (int) $request->input('per_page', 12);
        if (! in_array($perPage, [12, 25, 50, 100])) {
            $perPage = 12;
        }

        $projects = $projectsQuery
            ->orderBy($sortBy, $sortDirection)
            ->paginate($perPage)
            ->withQueryString();

        /*
        |--------------------------------------------------------------------------
        | تحديد المرحلة المعروضة لكل مشروع
        |--------------------------------------------------------------------------
        */

        foreach ($projects as $project) {
            $approvalChain = $project->projectApprovals;

            /*
             * 1) المرحلة النشطة الحالية.
             */
            $currentApproval = $approvalChain
                ->where('is_active', true)
                ->sortBy(function ($approval) {
                    return sprintf(
                        '%010d-%010d',
                        (int) ($approval->step_order ?? 0),
                        (int) ($approval->id ?? 0)
                    );
                })
                ->first();

            /*
             * 2) في حالة لم توجد active لأي سبب،
             *    نبحث عن pending.
             */
            if (! $currentApproval) {
                $currentApproval = $approvalChain
                    ->where('status', 'pending')
                    ->sortBy(function ($approval) {
                        return sprintf(
                            '%010d-%010d',
                            (int) ($approval->step_order ?? 0),
                            (int) ($approval->id ?? 0)
                        );
                    })
                    ->first();
            }

            /*
             * 3) المشاريع المنتهية التي يراها المدير:
             *    نعرض آخر مرحلة وصل إليها المشروع.
             */
            if (! $currentApproval) {
                $currentApproval = $approvalChain
                    ->sortByDesc(function ($approval) {
                        return sprintf(
                            '%010d-%010d',
                            (int) ($approval->step_order ?? 0),
                            (int) ($approval->id ?? 0)
                        );
                    })
                    ->first();
            }

            $project->setRelation(
                'currentApproval',
                $currentApproval
            );

            $project->current_approval =
                $currentApproval;

            /*
             * هل للمستخدم الحالي إجراء فعلي الآن؟
             *
             * المدير يستطيع مشاهدة المشروع، لكن can_user_act
             * يبقى معبراً عن صلاحية التنفيذ وليس المشاهدة.
             */
            $project->can_user_act = false;

            if ($currentApproval && $user) {
                $project->can_user_act =
                    (bool) $currentApproval->is_active
                    &&
                    $this->approvalService->canUserActOnStep(
                        $user,
                        $currentApproval
                    );
            }

            /*
             * هل يمكن فتح التفاصيل؟
             */
            if ($isAdmin) {
                $project->can_view_details = true;
            } else {
                $isRolledBackCreator =
                    $project->status === 'rolled_back_for_review'
                    &&
                    (
                        (int) $project->created_by_user_id
                            ===
                        (int) $user->id
                        ||
                        (
                            $userEntityId > 0
                            &&
                            (int) $project->creator_entity_id
                                ===
                            $userEntityId
                        )
                    );

                $project->can_view_details =
                    $project->can_user_act
                    ||
                    $isRolledBackCreator;
            }
        }

        /*
         * للتوافق مع أي Blade قديم يستخدم $approvalRecords.
         *
         * العناصر هنا Projects وليست ProjectApproval.
         */
        $approvalRecords = $projects;

        $entities = InternalEntity::withoutGlobalScopes()
            ->where('is_active', true)
            ->orderBy('name')
            ->get();

        $phases = ApprovalPhase::cases();
        $projectStatuses = ProjectStatus::cases();

        return view(
            'approvals.index',
            compact(
                'projects',
                'approvalRecords',
                'entities',
                'phases',
                'projectStatuses',
                'isAdmin'
            )
        );
    }

    /**
     * عرض تفاصيل الإحالة.
     */
    public function showReferral(
        ProjectReferral $referral
    ) {
        return app(
            ConsultationCenterController::class
        )->show(
            $referral
        );
    }

    /**
     * الرد على الإحالة.
     */
    public function respondReferral(
        RespondConsultationRequest $request,
        ProjectReferral $referral
    ) {
        return app(
            ConsultationCenterController::class
        )->respond(
            $request,
            $referral
        );
    }

    /**
     * تفاصيل المشروع في مركز الاعتمادات.
     *
     * قواعد الوصول:
     *
     * مدير النظام:
     * - يستطيع فتح أي مشروع.
     * - يرى كامل approval chain.
     * - يرى كامل Activity & Audit History.
     * - يرى كامل referrals.
     *
     * المستخدم العادي:
     * - يستطيع فتح المشروع فقط أثناء وجود مهمة حالية عليه.
     * - بمجرد انتقال المرحلة عنه يفقد الوصول من مركز الاعتمادات.
     * - إذا أعيد المشروع إليه كمنشئ، يستطيع فتحه حتى يعيد الإرسال.
     * - لا يتم إرسال سجل التدقيق الكامل إليه.
     */
    public function show(
        Project $project
    ) {
        $user = Auth::user();

        abort_unless($user, 403, 'Unauthorized');

        $userEntityId = (int) (
            $user->entity_id ?? 0
        );

        $isAdmin = method_exists(
            $user,
            'isAdmin'
        )
            ? (bool) $user->isAdmin()
            : false;

        /*
        |--------------------------------------------------------------------------
        | المرحلة النشطة
        |--------------------------------------------------------------------------
        */

        $activeStep =
            $this->approvalService
                ->getActiveStep(
                    $project
                );

        /*
         * حمّل علاقات المرحلة الحالية فقط قبل قرار الوصول.
         */
        if ($activeStep) {
            $activeStep->loadMissing([
                'entity',
                'reviewedByUser',
                'technicalReviewer',
                'financialReviewer',
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | هل المستخدم يستطيع الإجراء على المرحلة الحالية؟
        |--------------------------------------------------------------------------
        */

        $canActOnActiveStep = false;

        if (
            $activeStep
            &&
            $user
        ) {
            /*
             * شرط is_active مهم جداً:
             * إذا انتقلت المرحلة، لا يكفي أن المستخدم كان يستطيع
             * الإجراء عليها سابقاً.
             */
            $canActOnActiveStep =
                (bool) $activeStep->is_active
                &&
                $activeStep->status === 'pending'
                &&
                $this->approvalService
                    ->canUserActOnStep(
                        $user,
                        $activeStep
                    );
        }

        /*
        |--------------------------------------------------------------------------
        | المشروع المعاد للمنشئ
        |--------------------------------------------------------------------------
        */

        $isRolledBackCreator = false;

        if (
            $project->status === 'rolled_back_for_review'
        ) {
            $isRolledBackCreator =
                (
                    (int) $project->created_by_user_id
                        ===
                    (int) $user->id
                )
                ||
                (
                    $userEntityId > 0
                    &&
                    (int) $project->creator_entity_id
                        ===
                    $userEntityId
                );
        }

        /*
        |--------------------------------------------------------------------------
        | منع فتح رابط مشروع بعد انتقال المرحلة
        |--------------------------------------------------------------------------
        |
        | حتى لو احتفظ المستخدم بعنوان URL القديم:
        | بمجرد انتقال المرحلة عنه سيأخذ 403.
        |
        */

        if (
            ! $isAdmin
            &&
            ! $canActOnActiveStep
            &&
            ! $isRolledBackCreator
        ) {
            abort(
                403,
                'هذا المشروع لم يعد ضمن مرحلة الاعتماد المخصصة لك.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | البيانات الأساسية المشتركة
        |--------------------------------------------------------------------------
        */

        $project->load([
            'createdBy.entity',
            'creatorEntity',
            'cost',
            'executiveActionCosts',
            'financings.fundingSource',
            'documents',
        ]);

        /*
        |--------------------------------------------------------------------------
        | بيانات المدير = السجل الكامل
        |--------------------------------------------------------------------------
        */

        if ($isAdmin) {
            $project->load([
                /*
                 * جميع مراحل المشروع السابقة والحالية.
                 */
                'projectApprovals' => function ($query) {
                    $query
                        ->with([
                            'entity',
                            'reviewedByUser',
                            'technicalReviewer',
                            'financialReviewer',
                        ])
                        ->orderBy('step_order')
                        ->orderBy('id');
                },

                /*
                 * كامل Activity & Audit History.
                 */
                'activityHistory' => function ($query) {
                    $query
                        ->with('user')
                        ->orderByDesc('created_at')
                        ->orderByDesc('id');
                },

                /*
                 * كامل الإحالات والاستشارات.
                 */
                'referrals' => function ($query) {
                    $query
                        ->with([
                            'referringEntity',
                            'referredEntity',
                            'referringUser',
                            'respondingUser',
                        ])
                        ->orderByDesc('created_at')
                        ->orderByDesc('id');
                },
            ]);

            $approvalChain =
                $project->projectApprovals;

            $activityAuditHistory =
                $project->activityHistory;

            $referralHistory =
                $project->referrals;

            /*
             * تستخدم في Blade لإظهار قسم التدقيق الكامل.
             */
            $canViewFullAudit = true;
        } else {
            /*
            |--------------------------------------------------------------------------
            | بيانات المستخدم العادي = مرحلته الحالية فقط
            |--------------------------------------------------------------------------
            |
            | لا نرسل له تاريخ كل الإدارات والمستخدمين السابقين.
            |
            */

            if ($activeStep) {
                $approvalChain = collect([
                    $activeStep,
                ]);
            } elseif ($isRolledBackCreator) {
                /*
                 * عند الإعادة للمنشئ قد لا توجد مرحلة active.
                 * نظهر آخر مرحلة فقط حتى يفهم سبب عودة المشروع.
                 */
                $lastApproval = ProjectApproval::query()
                    ->with([
                        'entity',
                        'reviewedByUser',
                        'technicalReviewer',
                        'financialReviewer',
                    ])
                    ->where(
                        'project_id',
                        $project->id
                    )
                    ->orderByDesc('step_order')
                    ->orderByDesc('id')
                    ->first();

                $approvalChain = $lastApproval
                    ? collect([$lastApproval])
                    : collect();
            } else {
                $approvalChain = collect();
            }

            /*
             * المستخدم العادي لا يحصل على سجل التدقيق الكامل.
             */
            $activityAuditHistory = collect();

            /*
             * ولا يحصل على كامل الإحالات السابقة من مركز الاعتمادات.
             */
            $referralHistory = collect();

            $canViewFullAudit = false;

            /*
             * نضع العلاقة بشكل محدود أيضاً حتى لا يستخدم Blade
             * $project->projectApprovals ويعرض التاريخ الكامل بالخطأ.
             */
            $project->setRelation(
                'projectApprovals',
                $approvalChain
            );

            $project->setRelation(
                'activityHistory',
                collect()
            );

            $project->setRelation(
                'referrals',
                collect()
            );
        }

        /*
        |--------------------------------------------------------------------------
        | قائمة الجهات
        |--------------------------------------------------------------------------
        */

        $entitiesList =
            InternalEntity::withoutGlobalScopes()
                ->where(
                    'is_active',
                    true
                )
                ->when(
                    $userEntityId > 0,
                    function ($query) use ($userEntityId) {
                        $query->where(
                            'id',
                            '!=',
                            $userEntityId
                        );
                    }
                )
                ->orderBy('name')
                ->get();

        return view(
            'approvals.show',
            compact(
                'project',
                'activeStep',
                'canActOnActiveStep',
                'entitiesList',
                'approvalChain',
                'activityAuditHistory',
                'referralHistory',
                'isAdmin',
                'canViewFullAudit'
            )
        );
    }

    /**
     * تخزين مرفق الإحالة.
     */
    private function storeAttachment(
        $file,
        ?Project $project = null
    ): string {
        $fileName =
            time()
            . '_'
            . uniqid()
            . '_'
            . preg_replace(
                '/[^\w\.\-]/',
                '_',
                $file->getClientOriginalName()
            );

        $folder = $project
            ? "projects/{$project->id}/referral_attachments"
            : 'referrals/attachments';

        return $file->storeAs(
            $folder,
            $fileName,
            'public'
        );
    }
}

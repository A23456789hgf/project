<?php

namespace App\Http\Controllers\Admin;

use App\Enums\EntityResponsibilityType;
use App\Enums\UserResponsibilityType;
use App\Http\Controllers\Controller;
use App\Models\Authority;
use App\Models\AuthorityApprovalRoute;
use App\Models\AuthorityApprovalStage;
use App\Models\EntityApprovalStage;
use App\Models\InternalEntity;
use App\Models\ProjectApproval;
use App\Models\User;
use App\Services\ApprovalChainBuilder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class EntityApprovalStageController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:Admin');
    }

    public function index(Request $request)
    {
        $tab = $this->validatedTab($request);

        if ($tab === 'internal') {
            $query = EntityApprovalStage::withoutGlobalScopes()->with(['entity', 'responsibleUser']);
            if ($request->filled('entity_id')) {
                $query->where('entity_id', $request->entity_id);
            }
            $stages = $query->orderBy('entity_id')->orderBy('stage_order')->paginate(20)
                ->appends(['tab' => 'internal', 'entity_id' => $request->entity_id]);
            $entities = InternalEntity::withoutGlobalScopes()->orderBy('name')->get();

            return view('admin.entity-stages.index', compact('stages', 'entities', 'tab'));
        } else {
            $query = AuthorityApprovalStage::withoutGlobalScopes()->with(['authority', 'responsibleUser']);
            if ($request->filled('authority_id')) {
                $query->where('authority_id', $request->authority_id);
            }
            $stages = $query->orderBy('authority_id')->orderBy('stage_order')->paginate(20)
                ->appends(['tab' => 'external', 'authority_id' => $request->authority_id]);

            $authorities = Authority::withoutGlobalScopes()->orderBy('agency_name')->get();
            $routes = AuthorityApprovalRoute::withoutGlobalScopes()->with(['authority', 'destinationAuthority'])->get();

            return view('admin.entity-stages.index', compact('stages', 'authorities', 'routes', 'tab'));
        }
    }

    public function create(Request $request)
    {
        $tab = $this->validatedTab($request);
        $stageTypes = EntityResponsibilityType::orderedCases();

        if ($tab === 'internal') {
            $entities = InternalEntity::withoutGlobalScopes()->orderBy('name')->get();

            return view('admin.entity-stages.create', compact('entities', 'stageTypes', 'tab'));
        } else {
            $authorities = Authority::withoutGlobalScopes()->orderBy('agency_name')->get();

            return view('admin.entity-stages.create', compact('authorities', 'stageTypes', 'tab'));
        }
    }

    public function store(Request $request)
    {
        $tab = $this->validatedTab($request);

        if ($tab === 'internal') {
            $request->validate([
                'entity_id' => ['required', 'integer', Rule::exists('internal_entities', 'id')],
                'stages' => ['required', 'array', 'min:1'],
                'stages.*' => ['string', Rule::in(array_column(EntityResponsibilityType::cases(), 'value'))],
            ]);

            $entityId = $request->entity_id;
            $selectedStages = $request->stages;

            DB::transaction(function () use ($entityId, $selectedStages) {
                foreach (EntityResponsibilityType::orderedCases() as $stageType) {
                    if (in_array($stageType->value, $selectedStages)) {
                        EntityApprovalStage::updateOrCreate(
                            [
                                'entity_id' => $entityId,
                                'stage' => $stageType->value,
                            ],
                            [
                                'stage_order' => $stageType->stageOrder(),
                                'is_active' => false,
                                'responsible_user_id' => null,
                                'created_by' => Auth::id(),
                                'updated_by' => Auth::id(),
                            ]
                        );
                    }
                }
            });

            return redirect()->route('admin.entity-stages.index', ['tab' => 'internal'])->with('success', 'تم إضافة المراحل للجهة الداخلية بنجاح.');
        } else {
            $request->validate([
                'authority_id' => ['required', 'integer', Rule::exists('authorities', 'id')],
                'stages' => ['required', 'array', 'min:1'],
                'stages.*' => ['string', Rule::in(array_column(EntityResponsibilityType::cases(), 'value'))],
                'route_destination_type' => ['nullable', 'string', Rule::in(['ministry', 'authority'])],
                'destination_authority_id' => ['nullable', 'required_if:route_destination_type,authority', 'different:authority_id', 'integer', Rule::exists('authorities', 'id')],
            ]);

            $authorityId = $request->authority_id;
            $selectedStages = $request->stages;
            try {
                DB::transaction(function () use ($authorityId, $selectedStages, $request) {
                    foreach (EntityResponsibilityType::orderedCases() as $stageType) {
                        if (in_array($stageType->value, $selectedStages)) {
                            AuthorityApprovalStage::updateOrCreate(
                                [
                                    'authority_id' => $authorityId,
                                    'stage' => $stageType->value,
                                ],
                                [
                                    'stage_order' => $stageType->stageOrder(),
                                    'is_active' => false,
                                    'responsible_user_id' => null,
                                    'created_by' => Auth::id(),
                                    'updated_by' => Auth::id(),
                                ]
                            );
                        }
                    }

                    // Save route if provided
                    if ($request->filled('route_destination_type')) {
                        AuthorityApprovalRoute::updateOrCreate(
                            ['authority_id' => $authorityId],
                            [
                                'destination_type' => $request->route_destination_type,
                                'destination_authority_id' => $request->route_destination_type === 'authority' ? $request->destination_authority_id : null,
                                'is_active' => true,
                                'created_by' => Auth::id(),
                                'updated_by' => Auth::id(),
                            ]
                        );

                        $builder = app(ApprovalChainBuilder::class);
                        $validation = $builder->validateAuthorityRoute($authorityId);
                        if (! $validation['is_valid']) {
                            throw new \RuntimeException(
                                'مسار الجهة الخارجية غير صالح: '.$validation['error']
                            );
                        }
                    }
                });
            } catch (\Exception $e) {
                return back()->with('error', 'فشل في حفظ المسار: '.$e->getMessage())->withInput();
            }

            return redirect()->route('admin.entity-stages.index', ['tab' => 'external'])->with('success', 'تم إضافة المراحل للجهة الخارجية بنجاح.');
        }
    }

    public function edit($id, Request $request)
    {
        $tab = $this->validatedTab($request);
        $stageTypes = EntityResponsibilityType::orderedCases();

        if ($tab === 'internal') {
            $entity = InternalEntity::withoutGlobalScopes()->findOrFail($id);
            $entity->load('approvalStages');

            return view('admin.entity-stages.edit', compact('entity', 'stageTypes', 'tab'));
        } else {
            $authority = Authority::withoutGlobalScopes()->findOrFail($id);
            $stages = AuthorityApprovalStage::withoutGlobalScopes()->where('authority_id', $id)->get();
            $route = AuthorityApprovalRoute::withoutGlobalScopes()->where('authority_id', $id)->first();
            $authorities = Authority::withoutGlobalScopes()->where('id', '!=', $id)->orderBy('agency_name')->get();

            return view('admin.entity-stages.edit', compact('authority', 'stages', 'route', 'authorities', 'stageTypes', 'tab'));
        }
    }

    public function update(Request $request, $id)
    {
        $tab = $this->validatedTab($request);
        $stageTypes = EntityResponsibilityType::orderedCases();

        $rules = [];
        foreach ($stageTypes as $stageType) {
            $key = $stageType->value;
            $rules["stages.{$key}.enabled"] = ['nullable', 'boolean'];
            $rules["stages.{$key}.responsible_user_id"] = [
                'nullable',
                'integer',
                Rule::exists('users', 'id'),
            ];
        }

        if ($tab === 'external') {
            $rules['route_destination_type'] = ['nullable', 'string', Rule::in(['ministry', 'authority'])];
            $rules['destination_authority_id'] = [
                'nullable',
                'required_if:route_destination_type,authority',
                'integer',
                Rule::exists('authorities', 'id'),
            ];
        }

        $validated = $request->validate($rules);
        $stages = $validated['stages'] ?? [];
        $errors = [];

        if ($tab === 'internal') {
            $entity = InternalEntity::withoutGlobalScopes()->findOrFail($id);
            try {
                DB::transaction(function () use ($entity, $stageTypes, $stages, &$errors) {
                    foreach ($stageTypes as $stageType) {
                        $key = $stageType->value;
                        $isEnabled = ! empty($stages[$key]['enabled']);
                        $userId = $stages[$key]['responsible_user_id'] ?? null;

                        if (! $isEnabled) {
                            $hasPending = ProjectApproval::withoutGlobalScopes()
                                ->where(function ($scopeQuery) {
                                    $scopeQuery->where('approver_scope', 'internal')
                                        ->orWhereNull('approver_scope');
                                })
                                ->where('entity_id', $entity->id)
                                ->where('phase', $stageType->phaseCode())
                                ->where('status', 'pending')
                                ->exists();

                            if ($hasPending) {
                                $errors[$key] = "لا يمكن حذف مرحلة [{$stageType->label()}] لأن هناك معاملات نشطة تعتمد عليها.";

                                continue;
                            }

                            EntityApprovalStage::where('entity_id', $entity->id)
                                ->where('stage', $key)
                                ->update(['is_active' => false]);

                            continue;
                        }

                        if (! $userId) {
                            $errors[$key] = "يجب تحديد المستخدم المسؤول عن مرحلة [{$stageType->label()}].";

                            continue;
                        }

                        $user = User::withoutGlobalScopes()->find($userId);
                        $requiredResponsibility = UserResponsibilityType::forStage($stageType);

                        if (! $this->isValidResponsibleUser(
                            $user,
                            'internal',
                            (int) $entity->id,
                            $requiredResponsibility
                        )) {
                            $errors[$key] = "المستخدم المحدد لمرحلة [{$stageType->label()}] غير صالح، أو لا ينتمي للجهة الداخلية، أو أن مسؤوليته لا تتوافق مع المرحلة.";

                            continue;
                        }

                        EntityApprovalStage::updateOrCreate(
                            ['entity_id' => $entity->id, 'stage' => $key],
                            [
                                'stage_order' => $stageType->stageOrder(),
                                'is_active' => true,
                                'responsible_user_id' => $userId,
                                'updated_by' => Auth::id(),
                            ]
                        );
                    }

                    if (! empty($errors)) {
                        throw ValidationException::withMessages($errors);
                    }
                });
            } catch (ValidationException $e) {
                throw $e;
            } catch (\Exception $e) {
                return back()->with('error', 'فشل في حفظ البيانات: '.$e->getMessage())->withInput();
            }
        } else {
            $authority = Authority::withoutGlobalScopes()->findOrFail($id);

            if (
                $request->input('route_destination_type') === 'authority'
                && (int) $request->input('destination_authority_id') === (int) $authority->id
            ) {
                return back()
                    ->withErrors([
                        'destination_authority_id' => 'لا يمكن أن تكون الجهة الخارجية وجهةً لنفسها.',
                    ])
                    ->withInput();
            }

            try {
                DB::transaction(function () use ($authority, $stageTypes, $stages, $request, &$errors) {
                    foreach ($stageTypes as $stageType) {
                        $key = $stageType->value;
                        $isEnabled = ! empty($stages[$key]['enabled']);
                        $userId = $stages[$key]['responsible_user_id'] ?? null;

                        if (! $isEnabled) {
                            $hasPending = ProjectApproval::withoutGlobalScopes()
                                ->where('approver_scope', 'external')
                                ->where('authority_id', $authority->id)
                                ->where('phase', $stageType->phaseCode())
                                ->where('status', 'pending')
                                ->exists();

                            if ($hasPending) {
                                $errors[$key] = "لا يمكن حذف مرحلة [{$stageType->label()}] لأن هناك معاملات نشطة تعتمد عليها.";

                                continue;
                            }

                            AuthorityApprovalStage::where('authority_id', $authority->id)
                                ->where('stage', $key)
                                ->update(['is_active' => false]);

                            continue;
                        }

                        if (! $userId) {
                            $errors[$key] = "يجب تحديد المستخدم المسؤول عن مرحلة [{$stageType->label()}].";

                            continue;
                        }

                        $user = User::withoutGlobalScopes()->find($userId);
                        $requiredResponsibility = UserResponsibilityType::forStage($stageType);

                        if (! $this->isValidResponsibleUser(
                            $user,
                            'external',
                            (int) $authority->id,
                            $requiredResponsibility
                        )) {
                            $errors[$key] = "المستخدم المحدد لمرحلة [{$stageType->label()}] غير صالح، أو لا ينتمي للجهة الخارجية، أو أن مسؤوليته لا تتوافق مع المرحلة.";

                            continue;
                        }

                        AuthorityApprovalStage::updateOrCreate(
                            ['authority_id' => $authority->id, 'stage' => $key],
                            [
                                'stage_order' => $stageType->stageOrder(),
                                'is_active' => true,
                                'responsible_user_id' => $userId,
                                'updated_by' => Auth::id(),
                            ]
                        );
                    }

                    if (! empty($errors)) {
                        throw ValidationException::withMessages($errors);
                    }

                    // Route update
                    if ($request->filled('route_destination_type')) {
                        AuthorityApprovalRoute::updateOrCreate(
                            ['authority_id' => $authority->id],
                            [
                                'destination_type' => $request->route_destination_type,
                                'destination_authority_id' => $request->route_destination_type === 'authority' ? $request->destination_authority_id : null,
                                'is_active' => true,
                                'updated_by' => Auth::id(),
                            ]
                        );

                        $builder = app(ApprovalChainBuilder::class);
                        $validation = $builder->validateAuthorityRoute($authority->id);
                        if (! $validation['is_valid']) {
                            throw new \Exception($validation['error']);
                        }
                    }
                });
            } catch (ValidationException $e) {
                throw $e;
            } catch (\Exception $e) {
                return back()->with('error', 'فشل في حفظ المسار: '.$e->getMessage())->withInput();
            }
        }

        if (! empty($errors)) {
            return back()->withErrors($errors)->withInput()->with('warning', 'تم حفظ بعض المراحل مع وجود أخطاء.');
        }

        return redirect()->route('admin.entity-stages.index', ['tab' => $tab])->with('success', 'تم تحديث الإعدادات بنجاح.');
    }

    public function toggleActive($id, Request $request)
    {
        $tab = $this->validatedTab($request);

        if ($tab === 'internal') {
            $stage = EntityApprovalStage::withoutGlobalScopes()->findOrFail($id);
            if ($stage->is_active) {
                $stageType = EntityResponsibilityType::from($stage->stage);
                $hasPending = ProjectApproval::withoutGlobalScopes()
                    ->where(function ($scopeQuery) {
                        $scopeQuery->where('approver_scope', 'internal')
                            ->orWhereNull('approver_scope');
                    })
                    ->where('entity_id', $stage->entity_id)
                    ->where('phase', $stageType->phaseCode())
                    ->where('status', 'pending')
                    ->exists();

                if ($hasPending) {
                    return back()->with('error', 'لا يمكن إيقاف هذه المرحلة لوجود معاملات نشطة تعتمد عليها.');
                }
            } else {
                $stageType = EntityResponsibilityType::from($stage->stage);
                $requiredResponsibility = UserResponsibilityType::forStage($stageType);
                $responsibleUser = $stage->responsible_user_id
                    ? User::withoutGlobalScopes()->find($stage->responsible_user_id)
                    : null;

                if (! $this->isValidResponsibleUser(
                    $responsibleUser,
                    'internal',
                    (int) $stage->entity_id,
                    $requiredResponsibility
                )) {
                    return back()->with('error', 'لا يمكن تفعيل المرحلة قبل تحديد مستخدم داخلي نشط ومسؤوليته متوافقة مع نوع المرحلة.');
                }
            }

            $stage->update(['is_active' => ! $stage->is_active]);
        } else {
            $stage = AuthorityApprovalStage::withoutGlobalScopes()->findOrFail($id);
            if ($stage->is_active) {
                $stageType = EntityResponsibilityType::from($stage->stage);
                $hasPending = ProjectApproval::withoutGlobalScopes()
                    ->where('approver_scope', 'external')
                    ->where('authority_id', $stage->authority_id)
                    ->where('phase', $stageType->phaseCode())
                    ->where('status', 'pending')
                    ->exists();

                if ($hasPending) {
                    return back()->with('error', 'لا يمكن إيقاف هذه المرحلة لوجود معاملات نشطة تعتمد عليها.');
                }
            } else {
                $stageType = EntityResponsibilityType::from($stage->stage);
                $requiredResponsibility = UserResponsibilityType::forStage($stageType);
                $responsibleUser = $stage->responsible_user_id
                    ? User::withoutGlobalScopes()->find($stage->responsible_user_id)
                    : null;

                if (! $this->isValidResponsibleUser(
                    $responsibleUser,
                    'external',
                    (int) $stage->authority_id,
                    $requiredResponsibility
                )) {
                    return back()->with('error', 'لا يمكن تفعيل المرحلة قبل تحديد مستخدم خارجي نشط ومسؤوليته متوافقة مع نوع المرحلة.');
                }
            }

            $stage->update(['is_active' => ! $stage->is_active]);
        }

        return back()->with('success', 'تم تغيير حالة المرحلة بنجاح.');
    }

    public function destroy($id, Request $request)
    {
        $tab = $this->validatedTab($request);

        if ($tab === 'internal') {
            $stage = EntityApprovalStage::withoutGlobalScopes()->findOrFail($id);
            $stageType = EntityResponsibilityType::from($stage->stage);
            $hasPending = ProjectApproval::withoutGlobalScopes()
                ->where(function ($scopeQuery) {
                    $scopeQuery->where('approver_scope', 'internal')
                        ->orWhereNull('approver_scope');
                })
                ->where('entity_id', $stage->entity_id)
                ->where('phase', $stageType->phaseCode())
                ->where('status', 'pending')
                ->exists();

            if ($hasPending) {
                return back()->with('error', 'لا يمكن حذف هذه المرحلة لوجود معاملات نشطة تعتمد عليها.');
            }
            $stage->delete();
        } else {
            $stage = AuthorityApprovalStage::withoutGlobalScopes()->findOrFail($id);
            $stageType = EntityResponsibilityType::from($stage->stage);
            $hasPending = ProjectApproval::withoutGlobalScopes()
                ->where('approver_scope', 'external')
                ->where('authority_id', $stage->authority_id)
                ->where('phase', $stageType->phaseCode())
                ->where('status', 'pending')
                ->exists();

            if ($hasPending) {
                return back()->with('error', 'لا يمكن حذف هذه المرحلة لوجود معاملات نشطة تعتمد عليها.');
            }
            $stage->delete();
        }

        return back()->with('success', 'تم حذف المرحلة بنجاح.');
    }

    public function eligibleUsers(Request $request)
    {
        return $this->getEligibleUsers($request);
    }

    /**
     * Route-compatible endpoint.
     *
     * routes/web.php in the current project calls getEligibleUsers().
     * Keeping eligibleUsers() above preserves backward compatibility.
     */
    public function getEligibleUsers(Request $request)
    {
        $tab = $this->validatedTab($request);

        $request->validate([
            'entity_id' => [
                $tab === 'internal' ? 'required' : 'nullable',
                'nullable',
                'integer',
                Rule::exists('internal_entities', 'id'),
            ],
            'authority_id' => [
                $tab === 'external' ? 'required' : 'nullable',
                'nullable',
                'integer',
                Rule::exists('authorities', 'id'),
            ],
            'stage' => [
                'required',
                'string',
                Rule::in(array_column(EntityResponsibilityType::cases(), 'value')),
            ],
        ]);

        $stageType = EntityResponsibilityType::from($request->stage);
        $requiredResp = UserResponsibilityType::forStage($stageType);

        if ($tab === 'internal') {
            $users = User::withoutGlobalScopes()
                ->where('organization_type', 'internal')
                ->where('entity_id', (int) $request->entity_id)
                ->whereNull('authority_id')
                ->where('status', 'Active')
                ->where('responsibility', $requiredResp->value)
                ->orderBy('name')
                ->get(['id', 'name', 'user_id']);
        } else {
            $users = User::withoutGlobalScopes()
                ->where('organization_type', 'external')
                ->where('authority_id', (int) $request->authority_id)
                ->whereNull('entity_id')
                ->where('status', 'Active')
                ->where('responsibility', $requiredResp->value)
                ->orderBy('name')
                ->get(['id', 'name', 'user_id']);
        }

        return response()->json($users);
    }

    /**
     * Only the two supported configuration tabs are accepted.
     */
    private function validatedTab(Request $request): string
    {
        $tab = (string) $request->get('tab', 'internal');

        if (! in_array($tab, ['internal', 'external'], true)) {
            abort(422, 'نوع الجهة غير صالح.');
        }

        return $tab;
    }

    /**
     * Validate the responsible user against the exact organization and stage.
     */
    private function isValidResponsibleUser(
        ?User $user,
        string $organizationType,
        int $organizationId,
        UserResponsibilityType $requiredResponsibility
    ): bool {
        if (! $user || $user->status !== 'Active') {
            return false;
        }

        $responsibility = $user->responsibility instanceof UserResponsibilityType
            ? $user->responsibility
            : UserResponsibilityType::tryFrom((string) $user->responsibility);

        if ($responsibility !== $requiredResponsibility) {
            return false;
        }

        if ($organizationType === 'external') {
            return $user->organization_type === 'external'
                && (int) $user->authority_id === $organizationId
                && empty($user->entity_id);
        }

        return $user->organization_type === 'internal'
            && (int) $user->entity_id === $organizationId
            && empty($user->authority_id);
    }

}
<?php

namespace App\Services;

use App\Enums\EntityResponsibilityType;
use App\Enums\UserResponsibilityType;
use App\Exceptions\ConfigurationException;
use App\Models\Authority;
use App\Models\AuthorityApprovalRoute;
use App\Models\AuthorityApprovalStage;
use App\Models\EntityApprovalStage;
use App\Models\InternalEntity;
use App\Models\Project;

class ApprovalChainBuilder
{
    /**
     * Build the full dynamic approval chain stages for a project.
     *
     * External project:
     *   Authority -> [other external authorities] -> Ministry Root
     *
     * Internal project:
     *   Internal Entity -> Parent -> ... -> Ministry Root
     *
     * @throws ConfigurationException
     */
    public function buildChainForProject(Project $project): array
    {
        $sourceType = strtolower(trim((string) ($project->source_type ?? '')));

        /*
         * Backward compatibility:
         * المشاريع القديمة قد لا تحتوي على source_type.
         *
         * إذا وجد authority_id بدون مصدر داخلي واضح
         * نعتبر المشروع خارجيًا.
         */
        if ($sourceType === '') {
            $hasExternalOrigin = ! empty($project->authority_id);

            $hasInternalOrigin =
                ! empty($project->internal_entity_id)
                || ! empty($project->creator_entity_id);

            if ($hasExternalOrigin && ! $hasInternalOrigin) {
                $sourceType = 'external';
            } else {
                $sourceType = 'internal';
            }
        }

        if (! in_array($sourceType, ['internal', 'external'], true)) {
            throw new ConfigurationException(
                "نوع مصدر المشروع غير صالح: {$sourceType}. القيم المسموحة هي internal أو external."
            );
        }

        /*
         * External project
         */
        if ($sourceType === 'external') {
            $startAuthorityId = (int) ($project->authority_id ?? 0);

            if ($startAuthorityId <= 0) {
                throw new ConfigurationException(
                    'المشروع الخارجي لا يحتوي على authority_id للجهة الخارجية المقدمة للمشروع.'
                );
            }

            return $this->buildExternalChain($startAuthorityId);
        }

        /*
         * Internal project
         */
        $startEntityId = (int) (
            $project->internal_entity_id
            ?? $project->creator_entity_id
            ?? 0
        );

        if ($startEntityId <= 0) {
            throw new ConfigurationException(
                'المشروع الداخلي لا يحتوي على internal_entity_id أو creator_entity_id صالح.'
            );
        }

        return $this->buildInternalChain($startEntityId);
    }

    /**
     * Build internal approval chain:
     *
     * Internal Entity
     * -> Parent
     * -> Parent
     * -> Ministry Root
     *
     * @throws ConfigurationException
     */
    public function buildInternalChain(int $startEntityId): array
    {
        $ministryRoot = $this->resolveSingleMinistryRoot();

        $chain = [];

        $currentId = $startEntityId;

        $visited = [];

        $reachedMinistryRoot = false;

        while ($currentId > 0) {
            /*
             * Prevent circular parent relationships.
             */
            if (isset($visited[$currentId])) {
                throw new ConfigurationException(
                    'تم اكتشاف حلقة دائرية في الهيكل الداخلي للجهات أثناء بناء مسار الموافقات.'
                );
            }

            $visited[$currentId] = true;

            $current = InternalEntity::withoutGlobalScopes()
                ->find($currentId);

            if (! $current) {
                throw new ConfigurationException(
                    "تعذر بناء مسار الموافقات: الجهة الداخلية ذات المعرف {$currentId} غير موجودة."
                );
            }

            $isMinistryRoot =
                (int) $current->id === (int) $ministryRoot->id;

            $chain[] = [
                'type' => 'internal',

                'id' => (int) $current->id,

                'name' => (string) $current->name,

                'is_ministry_root' => $isMinistryRoot,
            ];

            /*
             * Stop immediately when Ministry Root is reached.
             */
            if ($isMinistryRoot) {
                $reachedMinistryRoot = true;

                break;
            }

            /*
             * Hierarchy ended before Ministry Root.
             */
            if (! $current->parent_id) {
                break;
            }

            $currentId = (int) $current->parent_id;
        }

        /*
         * Important:
         * An internal project must ALWAYS reach the Ministry Root.
         */
        if (! $reachedMinistryRoot) {
            $lastNode = end($chain);

            $lastName = is_array($lastNode)
                ? ($lastNode['name'] ?? 'غير معروف')
                : 'غير معروف';

            throw new ConfigurationException(
                "مسار الجهة الداخلية لا يصل إلى وزارة الزراعة المحددة كـ Ministry Root. آخر جهة تم الوصول إليها: {$lastName}."
            );
        }

        $stages = $this->expandChainIntoStages($chain);

        /*
         * Final safety validation.
         */
        $this->assertChainEndsWithMinistryApproval(
            $stages,
            $ministryRoot
        );

        return $stages;
    }

    /**
     * Build external approval chain:
     *
     * Authority
     * -> Optional External Authorities
     * -> Ministry Root
     *
     * @throws ConfigurationException
     */
    public function buildExternalChain(int $startAuthorityId): array
    {
        if ($startAuthorityId <= 0) {
            throw new ConfigurationException(
                'معرف الجهة الخارجية غير صالح.'
            );
        }

        /*
         * Validate the entire external route before
         * creating ProjectApproval stages.
         */
        $validation =
            $this->validateAuthorityRoute($startAuthorityId);

        if (! $validation['is_valid']) {
            throw new ConfigurationException(
                'مسار اعتماد الجهة الخارجية غير صالح: '
                .($validation['error']
                    ?? 'خطأ غير معروف في إعداد المسار.')
            );
        }

        $ministryRoot =
            $this->resolveSingleMinistryRoot();

        $stages =
            $this->expandChainIntoStages(
                $validation['path']
            );

        /*
         * External route must also end at
         * Ministry final APPROVAL.
         */
        $this->assertChainEndsWithMinistryApproval(
            $stages,
            $ministryRoot
        );

        return $stages;
    }

    /**
     * Validate an external authority route.
     *
     * Rules:
     *
     * - Every authority must exist.
     * - Every authority must have exactly ONE active route.
     * - Self routing is forbidden.
     * - Circular routing is forbidden.
     * - Route must terminate at Ministry Root.
     *
     * @return array{
     *     is_valid: bool,
     *     error: ?string,
     *     path: array<int,array<string,mixed>>
     * }
     */
    public function validateAuthorityRoute(
        int $startAuthorityId
    ): array {
        if ($startAuthorityId <= 0) {
            return $this->invalidRoute(
                'معرف الجهة الخارجية غير صالح.'
            );
        }

        /*
         * Ministry must be configured correctly
         * before an external route is considered valid.
         */
        try {
            $ministryRoot =
                $this->resolveSingleMinistryRoot();

        } catch (ConfigurationException $e) {
            return $this->invalidRoute(
                $e->getMessage()
            );
        }

        $currentAuthorityId =
            $startAuthorityId;

        $visitedAuthorities = [];

        $path = [];

        while (true) {
            /*
             * Circular route detection.
             */
            if (
                isset(
                    $visitedAuthorities[
                        $currentAuthorityId
                    ]
                )
            ) {
                return $this->invalidRoute(
                    'تم اكتشاف حلقة دائرية (Circular Route) في مسار الاعتمادات الخارجية.',
                    $path
                );
            }

            $visitedAuthorities[
                $currentAuthorityId
            ] = true;

            /*
             * Load authority without visibility scopes.
             */
            $authority =
                Authority::withoutGlobalScopes()
                    ->find($currentAuthorityId);

            if (! $authority) {
                return $this->invalidRoute(
                    "الجهة الخارجية ذات المعرف {$currentAuthorityId} غير موجودة.",
                    $path
                );
            }

            /*
             * Add current authority to path.
             */
            $path[] = [
                'type' => 'external',

                'id' => (int) $authority->id,

                'name' => (string) $authority->name,

                'is_ministry_root' => false,
            ];

            /*
             * Every Authority must have exactly
             * one active Approval Route.
             */
            $activeRoutes =
                AuthorityApprovalRoute::withoutGlobalScopes()
                    ->where(
                        'authority_id',
                        $currentAuthorityId
                    )
                    ->where(
                        'is_active',
                        true
                    )
                    ->orderBy('id')
                    ->get();

            if ($activeRoutes->isEmpty()) {
                return $this->invalidRoute(
                    "لا يوجد مسار اعتماد فعال للجهة الخارجية: {$authority->name}.",
                    $path
                );
            }

            if ($activeRoutes->count() > 1) {
                return $this->invalidRoute(
                    "يوجد أكثر من مسار اعتماد فعال للجهة الخارجية: {$authority->name}. يجب أن يكون لكل جهة خارجية مسار فعال واحد فقط.",
                    $path
                );
            }

            $route =
                $activeRoutes->first();

            $destinationType =
                strtolower(
                    trim(
                        (string)
                        $route->destination_type
                    )
                );

            /*
             * Direct to Ministry.
             */
            if (
                $destinationType ===
                'ministry'
            ) {
                /*
                 * destination_authority_id should
                 * not exist when destination is Ministry.
                 */
                if (
                    ! empty(
                        $route
                            ->destination_authority_id
                    )
                ) {
                    return $this->invalidRoute(
                        "إعداد مسار الجهة {$authority->name} غير متسق: الوجهة وزارة ولكن destination_authority_id يحتوي على قيمة.",
                        $path
                    );
                }

                $path[] = [
                    'type' => 'internal',

                    'id' =>
                        (int)
                        $ministryRoot->id,

                    'name' =>
                        (string)
                        $ministryRoot->name,

                    'is_ministry_root' =>
                        true,
                ];

                return [
                    'is_valid' => true,

                    'error' => null,

                    'path' => $path,
                ];
            }

            /*
             * Route to another External Authority.
             */
            if (
                $destinationType ===
                'authority'
            ) {
                $destinationAuthorityId =
                    (int) (
                        $route
                            ->destination_authority_id
                        ?? 0
                    );

                /*
                 * Destination must exist.
                 */
                if (
                    $destinationAuthorityId
                    <= 0
                ) {
                    return $this->invalidRoute(
                        "مسار الجهة {$authority->name} يوجه إلى جهة خارجية أخرى، لكن لم يتم تحديد destination_authority_id.",
                        $path
                    );
                }

                /*
                 * A -> A forbidden.
                 */
                if (
                    $destinationAuthorityId
                    ===
                    $currentAuthorityId
                ) {
                    return $this->invalidRoute(
                        "لا يمكن للجهة الخارجية {$authority->name} أن توجه مسار الاعتماد إلى نفسها.",
                        $path
                    );
                }

                /*
                 * Detect:
                 *
                 * A -> B -> A
                 * A -> B -> C -> B
                 * etc.
                 */
                if (
                    isset(
                        $visitedAuthorities[
                            $destinationAuthorityId
                        ]
                    )
                ) {
                    return $this->invalidRoute(
                        'تم اكتشاف حلقة دائرية (Circular Route) في مسار الاعتمادات الخارجية.',
                        $path
                    );
                }

                $currentAuthorityId =
                    $destinationAuthorityId;

                continue;
            }

            /*
             * Unknown destination_type.
             */
            return $this->invalidRoute(
                "نوع الوجهة غير صالح في مسار الجهة {$authority->name}: {$route->destination_type}.",
                $path
            );
        }
    }

    /**
     * Convert organizations in the resolved path
     * into individual ProjectApproval stages.
     *
     * @throws ConfigurationException
     */
    private function expandChainIntoStages(
        array $chain
    ): array {
        $stages = [];

        $order = 1;

        foreach ($chain as $node) {
            $nodeType =
                $node['type']
                ?? null;

            $nodeId =
                (int) (
                    $node['id']
                    ?? 0
                );

            $nodeName =
                (string) (
                    $node['name']
                    ?? 'جهة غير معروفة'
                );

            if ($nodeId <= 0) {
                throw new ConfigurationException(
                    "يوجد معرف جهة غير صالح داخل مسار الموافقات: {$nodeName}."
                );
            }

            /*
             * ============================================================
             * External Authority
             * ============================================================
             */
            if (
                $nodeType ===
                'external'
            ) {
                $configuredStages =
                    AuthorityApprovalStage::withoutGlobalScopes()
                        ->where(
                            'authority_id',
                            $nodeId
                        )
                        ->where(
                            'is_active',
                            true
                        )
                        ->with(
                            'responsibleUser'
                        )
                        ->orderBy(
                            'stage_order'
                        )
                        ->orderBy(
                            'id'
                        )
                        ->get();

                /*
                 * An Authority appearing in an approval path
                 * must have at least one active approval stage.
                 */
                if (
                    $configuredStages
                        ->isEmpty()
                ) {
                    throw new ConfigurationException(
                        "الجهة الخارجية: {$nodeName} | المشكلة: لا توجد أي مرحلة اعتماد فعالة ومهيأة لهذه الجهة."
                    );
                }

                foreach (
                    $configuredStages
                    as $stageConfig
                ) {
                    /*
                     * Convert:
                     *
                     * TECHNICAL_REVIEW
                     * FINANCIAL_REVIEW
                     * APPROVAL
                     *
                     * into the workflow-compatible phase codes.
                     */
                    $stageEnum =
                        $stageConfig
                            ->stageEnum();

                    if (! $stageEnum) {
                        throw new ConfigurationException(
                            "الجهة الخارجية: {$nodeName} | المشكلة: نوع المرحلة {$stageConfig->stage} غير معروف أو غير مدعوم."
                        );
                    }

                    /*
                     * Validate responsible user.
                     */
                    $this
                        ->assertResponsibleUserIsValid(
                            $stageConfig
                                ->responsibleUser,

                            $stageConfig
                                ->responsible_user_id,

                            $stageEnum,

                            'external',

                            $nodeId,

                            $nodeName
                        );

                    /*
                     * Critical:
                     *
                     * Use legacy-compatible ProjectApproval phase:
                     *
                     * TECHNICAL_REVIEW -> technical_review
                     * FINANCIAL_REVIEW -> financial_review
                     * APPROVAL -> stage_approval
                     */
                    $phaseCode =
                        $stageEnum
                            ->phaseCode();

                    $stages[] = [
                        'order' =>
                            $order++,

                        'code' =>
                            'authority_'
                            .$nodeId
                            .'_'
                            .$phaseCode,

                        'name_ar' =>
                            $nodeName
                            .' - '
                            .$stageEnum
                                ->label(),

                        'name_en' =>
                            $nodeName
                            .' - '
                            .$stageEnum
                                ->value,

                        'entity_id' =>
                            null,

                        'authority_id' =>
                            $nodeId,

                        'entity_name' =>
                            $nodeName,

                        'phase' =>
                            $phaseCode,

                        'is_entity_stage' =>
                            false,

                        'is_implementation' =>
                            false,

                        'responsible_user_id' =>
                            (int)
                            $stageConfig
                                ->responsible_user_id,

                        'stage_type' =>
                            $stageEnum
                                ->value,

                        'approver_scope' =>
                            'external',

                        'is_ministry_root' =>
                            false,
                    ];
                }

                continue;
            }

            /*
             * ============================================================
             * Internal Entity
             * ============================================================
             */
            if (
                $nodeType ===
                'internal'
            ) {
                $configuredStages =
                    EntityApprovalStage::withoutGlobalScopes()
                        ->where(
                            'entity_id',
                            $nodeId
                        )
                        ->where(
                            'is_active',
                            true
                        )
                        ->with(
                            'responsibleUser'
                        )
                        ->ordered()
                        ->get();

                foreach (
                    $configuredStages
                    as $stageConfig
                ) {
                    $stageEnum =
                        $stageConfig
                            ->stageEnum();

                    if (! $stageEnum) {
                        throw new ConfigurationException(
                            "الجهة الداخلية: {$nodeName} | المشكلة: نوع المرحلة {$stageConfig->stage} غير معروف أو غير مدعوم."
                        );
                    }

                    /*
                     * Validate responsible user including:
                     *
                     * - Active status
                     * - Same InternalEntity
                     * - Correct responsibility
                     */
                    $this
                        ->assertResponsibleUserIsValid(
                            $stageConfig
                                ->responsibleUser,

                            $stageConfig
                                ->responsible_user_id,

                            $stageEnum,

                            'internal',

                            $nodeId,

                            $nodeName
                        );

                    $phaseCode =
                        $stageEnum
                            ->phaseCode();

                    $stages[] = [
                        'order' =>
                            $order++,

                        'code' =>
                            'entity_'
                            .$nodeId
                            .'_'
                            .$phaseCode,

                        'name_ar' =>
                            $nodeName
                            .' - '
                            .$stageEnum
                                ->label(),

                        'name_en' =>
                            $nodeName
                            .' - '
                            .$stageEnum
                                ->value,

                        'entity_id' =>
                            $nodeId,

                        'authority_id' =>
                            null,

                        'entity_name' =>
                            $nodeName,

                        'phase' =>
                            $phaseCode,

                        'is_entity_stage' =>
                            true,

                        'is_implementation' =>
                            false,

                        'responsible_user_id' =>
                            (int)
                            $stageConfig
                                ->responsible_user_id,

                        'stage_type' =>
                            $stageEnum
                                ->value,

                        'approver_scope' =>
                            'internal',

                        'is_ministry_root' =>
                            (bool) (
                                $node[
                                    'is_ministry_root'
                                ]
                                ?? false
                            ),
                    ];
                }

                continue;
            }

            /*
             * Unknown node type.
             */
            throw new ConfigurationException(
                "نوع الجهة داخل مسار الموافقات غير معروف: {$nodeType}."
            );
        }

        return $stages;
    }

    /**
     * Retrieve the single configured Ministry Root.
     *
     * The workflow is invalid if:
     *
     * - no Ministry Root exists
     * - more than one Ministry Root exists
     *
     * @throws ConfigurationException
     */
    private function resolveSingleMinistryRoot():
        InternalEntity
    {
        $roots =
            InternalEntity::withoutGlobalScopes()
                ->where(
                    'is_ministry_root',
                    true
                )
                ->get();

        if ($roots->isEmpty()) {
            throw new ConfigurationException(
                'لم يتم إعداد وزارة الزراعة كجهة Ministry Root في النظام.'
            );
        }

        if ($roots->count() > 1) {
            throw new ConfigurationException(
                'إعداد النظام غير صالح: توجد أكثر من جهة داخلية محددة كـ Ministry Root. يجب أن توجد وزارة جذرية واحدة فقط.'
            );
        }

        return $roots->first();
    }

    /**
     * Validate the configured user responsible
     * for an approval stage.
     *
     * Required conditions:
     *
     * - user exists
     * - user is Active
     * - user belongs to the same organization
     * - internal/external organization type matches
     * - user's responsibility matches the stage
     *
     * @throws ConfigurationException
     */
    private function assertResponsibleUserIsValid(
        $user,
        ?int $responsibleUserId,
        EntityResponsibilityType $stageEnum,
        string $scope,
        int $organizationId,
        string $organizationName
    ): void {
        /*
         * Responsible user must exist.
         */
        if (
            ! $responsibleUserId
            || ! $user
        ) {
            throw new ConfigurationException(
                "الجهة: {$organizationName} | المرحلة: {$stageEnum->label()} | المشكلة: لم يتم تحديد مستخدم مسؤول صالح لهذه المرحلة."
            );
        }

        /*
         * User must be active.
         */
        if (
            $user->status
            !== 'Active'
        ) {
            throw new ConfigurationException(
                "الجهة: {$organizationName} | المرحلة: {$stageEnum->label()} | المشكلة: المستخدم المسؤول غير نشط."
            );
        }

        /*
         * External Authority user.
         */
        if ($scope === 'external') {
            if (
                ! $user->isExternal()
                ||
                (int) $user->authority_id
                    !==
                $organizationId
            ) {
                throw new ConfigurationException(
                    "الجهة الخارجية: {$organizationName} | المرحلة: {$stageEnum->label()} | المشكلة: المستخدم المسؤول لا يتبع نفس الجهة الخارجية."
                );
            }
        } else {
            /*
             * Internal Ministry user.
             */
            if (
                ! $user->isInternal()
                ||
                (int) $user->entity_id
                    !==
                $organizationId
            ) {
                throw new ConfigurationException(
                    "الجهة الداخلية: {$organizationName} | المرحلة: {$stageEnum->label()} | المشكلة: المستخدم المسؤول لا يتبع نفس الجهة الداخلية."
                );
            }
        }

        /*
         * Validate stage-specific responsibility.
         *
         * TECHNICAL_REVIEW
         * -> TECHNICAL
         *
         * FINANCIAL_REVIEW
         * -> FINANCIAL
         *
         * APPROVAL
         * -> ENTITY_APPROVER
         */
        $requiredResponsibility =
            UserResponsibilityType::forStage(
                $stageEnum
            );

        $actualResponsibility =
            $user->responsibility;

        /*
         * responsibility is normally cast to
         * UserResponsibilityType in User model,
         * but this also supports a raw DB string.
         */
        $actualResponsibilityValue =
            $actualResponsibility
            instanceof
            UserResponsibilityType

                ? $actualResponsibility
                    ->value

                : (string)
                    $actualResponsibility;

        if (
            $actualResponsibilityValue
            !==
            $requiredResponsibility->value
        ) {
            throw new ConfigurationException(
                "الجهة: {$organizationName} | المرحلة: {$stageEnum->label()} | المشكلة: مسؤولية المستخدم لا تطابق مسؤولية المرحلة المطلوبة ({$requiredResponsibility->value})."
            );
        }
    }

    /**
     * Final chain guard.
     *
     * The generated workflow MUST end with:
     *
     * Internal Ministry Root
     * +
     * APPROVAL
     *
     * This prevents malformed routes from reaching
     * ApprovalService.
     *
     * @throws ConfigurationException
     */
    private function assertChainEndsWithMinistryApproval(
        array $stages,
        InternalEntity $ministryRoot
    ): void {
        if (empty($stages)) {
            throw new ConfigurationException(
                'لم يتم توليد أي مراحل موافقة للمسار. تحقق من إعداد مراحل الجهات والمسؤولين عنها.'
            );
        }

        $lastStage =
            $stages[
                array_key_last(
                    $stages
                )
            ];

        /*
         * Must belong to Ministry Root.
         */
        $isMinistry =
            (
                $lastStage[
                    'approver_scope'
                ]
                ?? null
            ) === 'internal'

            &&

            (int) (
                $lastStage[
                    'entity_id'
                ]
                ?? 0
            )
            ===
            (int)
            $ministryRoot->id

            &&

            (bool) (
                $lastStage[
                    'is_ministry_root'
                ]
                ?? false
            );

        /*
         * Must be final APPROVAL stage.
         */
        $isFinalApproval =
            (
                $lastStage[
                    'phase'
                ]
                ?? null
            )
            ===
            EntityResponsibilityType
                ::Approval
                ->phaseCode()

            &&

            (
                $lastStage[
                    'stage_type'
                ]
                ?? null
            )
            ===
            EntityResponsibilityType
                ::Approval
                ->value;

        if (
            ! $isMinistry
            ||
            ! $isFinalApproval
        ) {
            throw new ConfigurationException(
                'مسار الموافقات غير مكتمل: يجب أن تكون آخر مرحلة هي مرحلة الاعتماد النهائي لوزارة الزراعة المحددة كـ Ministry Root.'
            );
        }
    }

    /**
     * Helper for standardized invalid-route responses.
     *
     * @return array{
     *     is_valid:false,
     *     error:string,
     *     path:array
     * }
     */
    private function invalidRoute(
        string $error,
        array $path = []
    ): array {
        return [
            'is_valid' => false,

            'error' => $error,

            'path' => $path,
        ];
    }
}
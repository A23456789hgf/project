<?php

namespace App\Models;

use App\Enums\ApprovalPhase;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProjectApproval extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * Approval scope values.
     */
    public const SCOPE_INTERNAL = 'internal';

    public const SCOPE_EXTERNAL = 'external';

    /**
     * Workflow phase values.
     */
    public const PHASE_TECHNICAL_REVIEW = 'technical_review';

    public const PHASE_FINANCIAL_REVIEW = 'financial_review';

    public const PHASE_STAGE_APPROVAL = 'stage_approval';

    /**
     * Mass assignable attributes.
     */
    protected $fillable = [
        'project_id',

        // Organization / approval ownership
        'approver_scope',
        'entity_id',
        'authority_id',
        'assigned_user_id',

        // Legacy workflow references
        'approval_flow_id',
        'stage_id',
        'stage_status_id',

        // Dynamic workflow
        'step_order',
        'drop',
        'phase',
        'status',
        'is_active',
        'is_completed',

        // General review information
        'notes',
        'attachment',
        'attachments',
        'required_action',
        'rejection_reason',

        // Legacy financial / technical review fields
        'financial_review_notes',
        'technical_review_notes',
        'financial_review_completed',
        'technical_review_completed',
        'financial_review_completed_at',
        'technical_review_completed_at',
        'financial_review_user_id',
        'technical_review_user_id',
        'reviewer_type',

        // Current entity-based workflow review fields
        'financial_review_status',
        'technical_review_status',
        'financial_reviewer_id',
        'technical_reviewer_id',
        'financial_reviewed_at',
        'technical_reviewed_at',
        'financial_notes',
        'technical_notes',
        'financial_attachment',
        'technical_attachment',

        // Return / revision workflow
        'return_target',
        'returned_from_stage',
        'returned_to_step_order',
        'returned_at',

        // Audit
        'created_by',
        'reviewed_at',
        'reviewed_by',
        'resubmitted_at',
        'resubmitted_by',
    ];

    /**
     * Attribute casts.
     */
    protected $casts = [
        'project_id' => 'integer',
        'entity_id' => 'integer',
        'authority_id' => 'integer',
        'assigned_user_id' => 'integer',
        'approval_flow_id' => 'integer',
        'stage_id' => 'integer',
        'stage_status_id' => 'integer',
        'step_order' => 'integer',

        'created_by' => 'integer',
        'reviewed_by' => 'integer',
        'resubmitted_by' => 'integer',

        'financial_reviewer_id' => 'integer',
        'technical_reviewer_id' => 'integer',
        'financial_review_user_id' => 'integer',
        'technical_review_user_id' => 'integer',

        'financial_review_completed' => 'boolean',
        'technical_review_completed' => 'boolean',

        'is_completed' => 'boolean',
        'is_active' => 'boolean',

        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
        'reviewed_at' => 'datetime',
        'resubmitted_at' => 'datetime',
        'returned_at' => 'datetime',

        'financial_review_completed_at' => 'datetime',
        'technical_review_completed_at' => 'datetime',
        'financial_reviewed_at' => 'datetime',
        'technical_reviewed_at' => 'datetime',

        'returned_to_step_order' => 'integer',

        'attachments' => 'array',

        'notes' => 'string',
        'financial_review_notes' => 'string',
        'technical_review_notes' => 'string',
        'required_action' => 'string',
        'rejection_reason' => 'string',
    ];

    // =========================================================================
    // RELATIONSHIPS
    // =========================================================================

    public function project(): BelongsTo
    {
        return $this->belongsTo(Project::class);
    }

    /**
     * User explicitly assigned to the approval phase.
     *
     * Normally used for stage_approval.
     */
    public function assignedUser(): BelongsTo
    {
        return $this->belongsTo(
            User::class,
            'assigned_user_id'
        );
    }

    /**
     * Internal organization responsible for this step.
     *
     * Must be NULL for external approval steps.
     */
    public function entity(): BelongsTo
    {
        return $this->belongsTo(
            InternalEntity::class,
            'entity_id'
        );
    }

    /**
     * External authority responsible for this step.
     *
     * Must be NULL for internal approval steps.
     */
    public function authority(): BelongsTo
    {
        return $this->belongsTo(
            Authority::class,
            'authority_id'
        );
    }

    public function financialReviewer(): BelongsTo
    {
        return $this->belongsTo(
            User::class,
            'financial_reviewer_id'
        );
    }

    public function technicalReviewer(): BelongsTo
    {
        return $this->belongsTo(
            User::class,
            'technical_reviewer_id'
        );
    }

    /**
     * Legacy financial reviewer relation.
     */
    public function financialReviewUser(): BelongsTo
    {
        return $this->belongsTo(
            User::class,
            'financial_review_user_id'
        );
    }

    /**
     * Legacy technical reviewer relation.
     */
    public function technicalReviewUser(): BelongsTo
    {
        return $this->belongsTo(
            User::class,
            'technical_review_user_id'
        );
    }

    public function reviewedByUser(): BelongsTo
    {
        return $this->belongsTo(
            User::class,
            'reviewed_by'
        );
    }

    public function approvalFlow(): BelongsTo
    {
        return $this->belongsTo(
            ApprovalFlow::class
        );
    }

    public function stage(): BelongsTo
    {
        return $this->belongsTo(
            Stage::class
        );
    }

    public function stageStatus(): BelongsTo
    {
        return $this->belongsTo(
            StageStatus::class
        );
    }

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(
            User::class,
            'created_by'
        );
    }

    // =========================================================================
    // QUERY SCOPES
    // =========================================================================

    public function scopeForProject(
        Builder $query,
        int $projectId
    ): Builder {
        return $query->where(
            'project_id',
            $projectId
        );
    }

    public function scopeByStatus(
        Builder $query,
        string $status
    ): Builder {
        return $query->where(
            'status',
            $status
        );
    }

    public function scopeOrderedByStep(
        Builder $query
    ): Builder {
        return $query->orderBy(
            'step_order'
        );
    }

    public function scopeActive(
        Builder $query
    ): Builder {
        return $query->where(
            'is_active',
            true
        );
    }

    public function scopeLocked(
        Builder $query
    ): Builder {
        return $query->where(
            'status',
            'locked'
        );
    }

    public function scopeApproved(
        Builder $query
    ): Builder {
        return $query->where(
            'status',
            'approved'
        );
    }

    public function scopeRejected(
        Builder $query
    ): Builder {
        return $query->where(
            'status',
            'rejected'
        );
    }

    public function scopePending(
        Builder $query
    ): Builder {
        return $query->where(
            'status',
            'pending'
        );
    }

    /**
     * Internal approval steps only.
     *
     * Important:
     * Do not use this scope for external authorities.
     */
    public function scopeForEntity(
        Builder $query,
        int $entityId
    ): Builder {
        return $query
            ->where(
                'approver_scope',
                self::SCOPE_INTERNAL
            )
            ->where(
                'entity_id',
                $entityId
            );
    }

    /**
     * External approval steps only.
     *
     * This prevents ID collision between:
     *
     * internal_entities.id
     * authorities.id
     */
    public function scopeForAuthority(
        Builder $query,
        int $authorityId
    ): Builder {
        return $query
            ->where(
                'approver_scope',
                self::SCOPE_EXTERNAL
            )
            ->where(
                'authority_id',
                $authorityId
            );
    }

    public function scopeInternal(
        Builder $query
    ): Builder {
        return $query->where(
            'approver_scope',
            self::SCOPE_INTERNAL
        );
    }

    public function scopeExternal(
        Builder $query
    ): Builder {
        return $query->where(
            'approver_scope',
            self::SCOPE_EXTERNAL
        );
    }

    public function scopeFinancialReview(
        Builder $query
    ): Builder {
        return $query->where(
            'phase',
            self::PHASE_FINANCIAL_REVIEW
        );
    }

    public function scopeTechnicalReview(
        Builder $query
    ): Builder {
        return $query->where(
            'phase',
            self::PHASE_TECHNICAL_REVIEW
        );
    }

    public function scopeStageApproval(
        Builder $query
    ): Builder {
        return $query->where(
            'phase',
            self::PHASE_STAGE_APPROVAL
        );
    }

    public function scopeByReviewerType(
        Builder $query,
        string $type
    ): Builder {
        return $query->where(
            'reviewer_type',
            $type
        );
    }

    // =========================================================================
    // ORGANIZATION HELPERS
    // =========================================================================

    /**
     * Determine whether this approval belongs
     * to an internal Ministry entity.
     */
    public function isInternalScope(): bool
    {
        return $this->approver_scope === self::SCOPE_INTERNAL;
    }

    /**
     * Determine whether this approval belongs
     * to an external authority.
     */
    public function isExternalScope(): bool
    {
        return $this->approver_scope === self::SCOPE_EXTERNAL;
    }

    /**
     * Return the organization ID without mixing
     * InternalEntity IDs with Authority IDs.
     */
    public function getApproverOrganizationId(): ?int
    {
        if ($this->isExternalScope()) {
            return $this->authority_id
                ? (int) $this->authority_id
                : null;
        }

        if ($this->isInternalScope()) {
            return $this->entity_id
                ? (int) $this->entity_id
                : null;
        }

        return null;
    }

    /**
     * Return the responsible organization's name.
     */
    public function getApproverOrganizationName(): string
    {
        if ($this->isExternalScope()) {
            return $this->authority?->name
                ?? 'جهة خارجية';
        }

        if ($this->isInternalScope()) {
            return $this->entity?->name
                ?? 'جهة داخلية';
        }

        /*
         * Backward compatibility for old records
         * where approver_scope may be NULL.
         */
        if ($this->authority_id) {
            return $this->authority?->name
                ?? 'جهة خارجية';
        }

        if ($this->entity_id) {
            return $this->entity?->name
                ?? 'جهة داخلية';
        }

        return 'الجهة';
    }

    /**
     * Validate that entity/authority fields are
     * consistent with approver_scope.
     */
    public function hasValidApproverScope(): bool
    {
        if ($this->isInternalScope()) {
            return ! empty($this->entity_id)
                && empty($this->authority_id);
        }

        if ($this->isExternalScope()) {
            return ! empty($this->authority_id)
                && empty($this->entity_id);
        }

        return false;
    }

    // =========================================================================
    // STATUS HELPERS
    // =========================================================================

    public function isActive(): bool
    {
        return (bool) $this->is_active
            && $this->isPending();
    }

    public function isLocked(): bool
    {
        return $this->status === 'locked';
    }

    public function isApproved(): bool
    {
        return $this->status === 'approved';
    }

    public function isRejected(): bool
    {
        return $this->status === 'rejected';
    }

    public function isPending(): bool
    {
        return $this->status === 'pending';
    }

    public function isNeedAction(): bool
    {
        return in_array(
            $this->status,
            [
                'need_action',
                'requires_action',
            ],
            true
        );
    }

    // =========================================================================
    // PHASE HELPERS
    // =========================================================================

    /**
     * Resolve the workflow phase.
     *
     * New records should always use:
     *
     * technical_review
     * financial_review
     * stage_approval
     *
     * The drop fallback exists only for
     * backward compatibility.
     */
    public function getPhaseEnum(): ?ApprovalPhase
    {
        /*
         * Preferred source:
         * explicit phase column.
         */
        if ($this->phase) {
            $normalizedPhase =
                $this->normalizePhase(
                    $this->phase
                );

            $phaseEnum =
                ApprovalPhase::tryFrom(
                    $normalizedPhase
                );

            if ($phaseEnum) {
                return $phaseEnum;
            }
        }

        /*
         * Backward compatibility:
         *
         * entity_5_technical_review
         * authority_7_technical_review
         *
         * Both internal and external drops
         * are supported.
         */
        if ($this->drop) {
            if (
                str_ends_with(
                    $this->drop,
                    '_technical_review'
                )
            ) {
                return ApprovalPhase::TechnicalReview;
            }

            if (
                str_ends_with(
                    $this->drop,
                    '_financial_review'
                )
            ) {
                return ApprovalPhase::FinancialReview;
            }

            if (
                str_ends_with(
                    $this->drop,
                    '_stage_approval'
                )
            ) {
                return ApprovalPhase::StageApproval;
            }

            /*
             * Legacy external format:
             *
             * authority_5_TECHNICAL_REVIEW
             * authority_5_FINANCIAL_REVIEW
             * authority_5_APPROVAL
             */
            $upperDrop = strtoupper(
                $this->drop
            );

            if (
                str_ends_with(
                    $upperDrop,
                    '_TECHNICAL_REVIEW'
                )
            ) {
                return ApprovalPhase::TechnicalReview;
            }

            if (
                str_ends_with(
                    $upperDrop,
                    '_FINANCIAL_REVIEW'
                )
            ) {
                return ApprovalPhase::FinancialReview;
            }

            if (
                str_ends_with(
                    $upperDrop,
                    '_APPROVAL'
                )
            ) {
                return ApprovalPhase::StageApproval;
            }
        }

        return null;
    }

    /**
     * Normalize old stage values to the
     * ProjectApproval phase values.
     */
    private function normalizePhase(
        string $phase
    ): string {
        $phase = trim($phase);

        return match (
            strtoupper($phase)
        ) {
            'TECHNICAL_REVIEW' =>
                self::PHASE_TECHNICAL_REVIEW,

            'FINANCIAL_REVIEW' =>
                self::PHASE_FINANCIAL_REVIEW,

            'APPROVAL',
            'STAGE_APPROVAL' =>
                self::PHASE_STAGE_APPROVAL,

            default =>
                strtolower($phase),
        };
    }

    public function getPhaseLabel(): string
    {
        return $this
            ->getPhaseEnum()
            ?->label()
            ?? 'اعتماد';
    }

    public function getPhaseArabicName(): string
    {
        return $this->getPhaseLabel();
    }

    /**
     * Resolve a human-readable stage name
     * for both internal and external approvals.
     *
     * Examples:
     *
     * وزارة الزراعة - المراجعة الفنية
     * مؤسسة خيرية - المراجعة المالية
     * محافظة صنعاء - الاعتماد
     */
    public function getResolvedStageName(): string
    {
        $organizationName =
            $this
                ->getApproverOrganizationName();

        $phaseLabel =
            $this
                ->getPhaseLabel();

        return "{$organizationName} - {$phaseLabel}";
    }

    public function isTechnicalReview(): bool
    {
        return $this->getPhaseEnum()
            === ApprovalPhase::TechnicalReview;
    }

    public function isFinancialReview(): bool
    {
        return $this->getPhaseEnum()
            === ApprovalPhase::FinancialReview;
    }

    public function isStageApproval(): bool
    {
        return $this->getPhaseEnum()
            === ApprovalPhase::StageApproval;
    }

    /**
     * Determine whether this step represents
     * the Ministry Root final approval.
     *
     * This is a helper only.
     * ApprovalService remains responsible for
     * deciding when a project enters execution.
     */
    public function isMinistryFinalApproval(): bool
    {
        if (! $this->isInternalScope()) {
            return false;
        }

        if (! $this->isStageApproval()) {
            return false;
        }

        if (! $this->entity_id) {
            return false;
        }

        return (bool) (
            $this->entity
                ?->is_ministry_root
        );
    }

    // =========================================================================
    // RESPONSIBLE USER HELPERS
    // =========================================================================

    /**
     * Get the explicit responsible user ID
     * according to the current phase.
     *
     * No organization-level fallback is used.
     */
    public function getResponsibleUserId(): ?int
    {
        if ($this->isTechnicalReview()) {
            $id =
                $this->technical_reviewer_id
                ?? $this->technical_review_user_id;

            return $id
                ? (int) $id
                : null;
        }

        if ($this->isFinancialReview()) {
            $id =
                $this->financial_reviewer_id
                ?? $this->financial_review_user_id;

            return $id
                ? (int) $id
                : null;
        }

        if ($this->isStageApproval()) {
            return $this->assigned_user_id
                ? (int) $this->assigned_user_id
                : null;
        }

        return $this->assigned_user_id
            ? (int) $this->assigned_user_id
            : null;
    }

    /**
     * Determine whether the supplied user is
     * the explicitly assigned responsible user.
     *
     * This intentionally does NOT fall back to:
     *
     * same entity
     * or
     * same authority
     *
     * because that would allow another user
     * from the organization to approve the step.
     */
    public function isAssignedTo(
        User $user
    ): bool {
        $responsibleUserId =
            $this->getResponsibleUserId();

        if (! $responsibleUserId) {
            return false;
        }

        return $responsibleUserId
            === (int) $user->id;
    }

    /**
     * Validate that the supplied user belongs
     * to the exact approval organization.
     */
    public function userBelongsToApproverOrganization(
        User $user
    ): bool {
        if ($this->isExternalScope()) {
            return $user->isExternal()
                && ! empty($this->authority_id)
                && (int) $user->authority_id
                    ===
                    (int) $this->authority_id;
        }

        if ($this->isInternalScope()) {
            return $user->isInternal()
                && ! empty($this->entity_id)
                && (int) $user->entity_id
                    ===
                    (int) $this->entity_id;
        }

        return false;
    }

    // =========================================================================
    // LEGACY REVIEWER HELPERS
    // =========================================================================

    public function isFinancialReviewer(): bool
    {
        return $this->reviewer_type === 'financial'
            || $this->isFinancialReview();
    }

    public function isTechnicalReviewer(): bool
    {
        return $this->reviewer_type === 'technical'
            || $this->isTechnicalReview();
    }

    public function isGeneralReviewer(): bool
    {
        return $this->reviewer_type === 'general'
            || $this->reviewer_type === null;
    }

    // =========================================================================
    // MUTATORS
    // =========================================================================

    protected function setApproverScopeAttribute(
        $value
    ): void {
        $value = strtolower(
            trim(
                (string) $value
            )
        );

        $this->attributes[
            'approver_scope'
        ] = $value;
    }

    /**
     * Normalize all new phase writes.
     *
     * This means even if old code sends:
     *
     * TECHNICAL_REVIEW
     * FINANCIAL_REVIEW
     * APPROVAL
     *
     * the database receives:
     *
     * technical_review
     * financial_review
     * stage_approval
     */
    protected function setPhaseAttribute(
        $value
    ): void {
        if ($value === null || $value === '') {
            $this->attributes['phase'] = null;

            return;
        }

        $this->attributes['phase'] =
            $this->normalizePhase(
                (string) $value
            );
    }

    protected function setNotesAttribute(
        $value
    ): void {
        $this->attributes['notes'] =
            $this->normalizeTextValue(
                $value
            );
    }

    protected function setFinancialReviewNotesAttribute(
        $value
    ): void {
        $this->attributes[
            'financial_review_notes'
        ] =
            $this->normalizeTextValue(
                $value
            );
    }

    protected function setTechnicalReviewNotesAttribute(
        $value
    ): void {
        $this->attributes[
            'technical_review_notes'
        ] =
            $this->normalizeTextValue(
                $value
            );
    }

    protected function setRequiredActionAttribute(
        $value
    ): void {
        $this->attributes[
            'required_action'
        ] =
            $this->normalizeTextValue(
                $value
            );
    }

    protected function setRejectionReasonAttribute(
        $value
    ): void {
        $this->attributes[
            'rejection_reason'
        ] =
            $this->normalizeTextValue(
                $value
            );
    }

    /**
     * Normalize text fields that historically
     * sometimes received arrays.
     */
    private function normalizeTextValue(
        $value
    ): string {
        if (is_array($value)) {
            return implode(
                ', ',
                array_filter(
                    array_map(
                        static fn ($item) =>
                            is_scalar($item)
                                ? (string) $item
                                : '',
                        $value
                    )
                )
            );
        }

        return (string) (
            $value
            ?? ''
        );
    }
}
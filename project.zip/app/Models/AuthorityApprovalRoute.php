 
<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AuthorityApprovalRoute extends Model
{
    use HasFactory;

    public const DESTINATION_MINISTRY = 'ministry';
    public const DESTINATION_AUTHORITY = 'authority';

    protected $fillable = [
        'authority_id',
        'destination_type',
        'destination_authority_id',
        'is_active',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'authority_id' => 'integer',
        'destination_authority_id' => 'integer',
        'is_active' => 'boolean',
        'created_by' => 'integer',
        'updated_by' => 'integer',
    ];

    /*
    |--------------------------------------------------------------------------
    | Relationships
    |--------------------------------------------------------------------------
    */

    /**
     * الجهة الخارجية صاحبة المسار.
     */
    public function authority(): BelongsTo
    {
        return $this->belongsTo(
            Authority::class,
            'authority_id'
        );
    }

    /**
     * الجهة الخارجية التالية في المسار.
     *
     * تكون NULL عندما تكون الوجهة هي الوزارة.
     */
    public function destinationAuthority(): BelongsTo
    {
        return $this->belongsTo(
            Authority::class,
            'destination_authority_id'
        );
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(
            User::class,
            'created_by'
        )->withoutGlobalScopes();
    }

    public function updater(): BelongsTo
    {
        return $this->belongsTo(
            User::class,
            'updated_by'
        )->withoutGlobalScopes();
    }

    /*
    |--------------------------------------------------------------------------
    | Scopes
    |--------------------------------------------------------------------------
    */

    /**
     * المسارات المفعلة فقط.
     */
    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    /**
     * مسار جهة خارجية محددة.
     */
    public function scopeForAuthority(
        Builder $query,
        int $authorityId
    ): Builder {
        return $query->where(
            'authority_id',
            $authorityId
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Destination Helpers
    |--------------------------------------------------------------------------
    */

    /**
     * هل الوجهة النهائية هي الوزارة؟
     */
    public function goesToMinistry(): bool
    {
        return $this->destination_type === self::DESTINATION_MINISTRY;
    }

    /**
     * هل الوجهة جهة خارجية أخرى؟
     */
    public function goesToAuthority(): bool
    {
        return $this->destination_type === self::DESTINATION_AUTHORITY;
    }

    /**
     * الحصول على ID الجهة الخارجية التالية.
     *
     * يعيد NULL إذا كانت الوجهة الوزارة.
     */
    public function getNextAuthorityId(): ?int
    {
        if (! $this->goesToAuthority()) {
            return null;
        }

        $id = (int) ($this->destination_authority_id ?? 0);

        return $id > 0 ? $id : null;
    }

    /*
    |--------------------------------------------------------------------------
    | Validation
    |--------------------------------------------------------------------------
    */

    /**
     * التحقق من صحة بيانات هذا المسار نفسه.
     *
     * ملاحظة:
     * هذا التحقق يختص بالسجل الحالي فقط.
     * فحص كامل السلسلة ومنع A -> B -> A يجب أن يبقى أيضاً
     * داخل ApprovalChainBuilder.
     */
    public function isValidRoute(): bool
    {
        return $this->validationError() === null;
    }

    /**
     * إرجاع سبب عدم صلاحية المسار.
     */
    public function validationError(): ?string
    {
        $authorityId = (int) ($this->authority_id ?? 0);

        if ($authorityId <= 0) {
            return 'لم يتم تحديد الجهة الخارجية صاحبة المسار.';
        }

        if (! in_array(
            $this->destination_type,
            [
                self::DESTINATION_MINISTRY,
                self::DESTINATION_AUTHORITY,
            ],
            true
        )) {
            return 'نوع وجهة مسار الموافقة غير صالح.';
        }

        /*
         * Authority -> Ministry
         *
         * لا يجوز الاحتفاظ بـ destination_authority_id
         * عند اختيار الوزارة.
         */
        if ($this->goesToMinistry()) {
            if (! empty($this->destination_authority_id)) {
                return 'عند اختيار الوزارة كوجهة يجب ألا توجد جهة خارجية تالية.';
            }

            return null;
        }

        /*
         * Authority -> Authority
         */
        $destinationAuthorityId =
            (int) ($this->destination_authority_id ?? 0);

        if ($destinationAuthorityId <= 0) {
            return 'يجب تحديد الجهة الخارجية التالية في مسار الموافقة.';
        }

        /*
         * منع:
         *
         * A -> A
         */
        if ($destinationAuthorityId === $authorityId) {
            return 'لا يمكن توجيه مسار الموافقة من الجهة الخارجية إلى نفسها.';
        }

        /*
         * التحقق من وجود الجهة التالية.
         */
        $destinationExists = Authority::withoutGlobalScopes()
            ->whereKey($destinationAuthorityId)
            ->exists();

        if (! $destinationExists) {
            return 'الجهة الخارجية التالية في مسار الموافقة غير موجودة.';
        }

        return null;
    }

    /*
    |--------------------------------------------------------------------------
    | Full Chain Validation
    |--------------------------------------------------------------------------
    */

    /**
     * فحص أن السلسلة ابتداءً من هذه الجهة:
     *
     * - لا تحتوي دورة.
     * - لا تعيد المرور على نفس Authority.
     * - كل Authority لها مسار فعال واحد.
     * - تنتهي في النهاية بالوزارة.
     *
     * هذا الفحص لا يستخدم authorities.parent_id إطلاقاً.
     */
    public function validateFullChain(): array
    {
        $currentAuthorityId = (int) $this->authority_id;
        $visited = [];
        $path = [];

        if ($currentAuthorityId <= 0) {
            return [
                'is_valid' => false,
                'error' => 'لم يتم تحديد الجهة الخارجية صاحبة المسار.',
                'path' => [],
            ];
        }

        while ($currentAuthorityId > 0) {
            if (in_array($currentAuthorityId, $visited, true)) {
                return [
                    'is_valid' => false,
                    'error' => 'تم اكتشاف مسار دائري بين الجهات الخارجية.',
                    'path' => $path,
                ];
            }

            $visited[] = $currentAuthorityId;
            $path[] = [
                'type' => 'authority',
                'authority_id' => $currentAuthorityId,
            ];

            /*
             * يجب أن يكون لكل جهة مسار فعال واحد فقط.
             */
            $routes = self::withoutGlobalScopes()
                ->where('authority_id', $currentAuthorityId)
                ->where('is_active', true)
                ->get();

            if ($routes->isEmpty()) {
                return [
                    'is_valid' => false,
                    'error' =>
                        "لا يوجد مسار موافقة فعال للجهة الخارجية رقم {$currentAuthorityId}.",
                    'path' => $path,
                ];
            }

            if ($routes->count() > 1) {
                return [
                    'is_valid' => false,
                    'error' =>
                        "يوجد أكثر من مسار موافقة فعال للجهة الخارجية رقم {$currentAuthorityId}.",
                    'path' => $path,
                ];
            }

            /** @var self $route */
            $route = $routes->first();

            $routeError = $route->validationError();

            if ($routeError !== null) {
                return [
                    'is_valid' => false,
                    'error' => $routeError,
                    'path' => $path,
                ];
            }

            /*
             * وصلنا إلى الوزارة.
             */
            if ($route->goesToMinistry()) {
                $path[] = [
                    'type' => 'ministry',
                    'authority_id' => null,
                ];

                return [
                    'is_valid' => true,
                    'error' => null,
                    'path' => $path,
                ];
            }

            /*
             * الانتقال إلى Authority التالية.
             */
            $nextAuthorityId = $route->getNextAuthorityId();

            if (! $nextAuthorityId) {
                return [
                    'is_valid' => false,
                    'error' =>
                        'مسار الموافقة يشير إلى جهة خارجية ولكن لم يتم تحديد الجهة التالية.',
                    'path' => $path,
                ];
            }

            $currentAuthorityId = $nextAuthorityId;
        }

        return [
            'is_valid' => false,
            'error' => 'تعذر الوصول إلى الوزارة من مسار الجهة الخارجية.',
            'path' => $path,
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | Model Events
    |--------------------------------------------------------------------------
    */

    protected static function booted(): void
    {
        /*
         * إذا كانت الوجهة الوزارة فلا معنى للاحتفاظ
         * بـ destination_authority_id.
         */
        static::saving(function (self $route): void {
            if ($route->destination_type === self::DESTINATION_MINISTRY) {
                $route->destination_authority_id = null;
            }
        });
    }
}
 
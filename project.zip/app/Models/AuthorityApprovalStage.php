<?php

namespace App\Models;

use App\Traits\HasActiveScope;
use App\Traits\HasCreatorTracking;
use App\Traits\HasDomainScope;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class Authority extends Model
{
    use HasActiveScope, HasCreatorTracking, HasDomainScope, HasFactory;

    protected $fillable = [
        'status',
        'agency_name',
        'parent_id',
        'governorate_id',
        'directorate_id',
        'type_entity_id',
        'is_active',
        'is_funded',
        'creator_username',
        'creator_entity_id',
        'entity_scope',
        'financing_type_id',
        'financing_form_id',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'is_funded' => 'boolean',
    ];

    // -----------------------------------------------------------------------
    // Relationships
    // -----------------------------------------------------------------------

    public function parent(): BelongsTo
    {
        return $this->belongsTo(Authority::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(Authority::class, 'parent_id');
    }

    public function governorate()
    {
        return $this->belongsTo(Governorate::class, 'governorate_id');
    }

    public function directorate(): BelongsTo
    {
        return $this->belongsTo(Directorate::class, 'directorate_id');
    }

    /**
     * العلاقة مع نوع الكيان (Entity Type)
     */
    public function typeEntity(): BelongsTo
    {
        return $this->belongsTo(TypeEntity::class, 'type_entity_id');
    }

    public function financingType(): BelongsTo
    {
        return $this->belongsTo(FinancingType::class, 'financing_type_id');
    }

    public function financingForm(): BelongsTo
    {
        return $this->belongsTo(FormFinancing::class, 'financing_form_id');
    }

    public function activeChildren(): HasMany
    {
        return $this->children()->where('is_active', true);
    }

    public function approvalFlows(): HasMany
    {
        return $this->hasMany(ApprovalFlow::class);
    }

    public function projectApprovals(): HasMany
    {
        return $this->hasMany(ProjectApproval::class, 'authority_id');
    }

    /**
     * Configured approval stages for this external authority.
     *
     * These stages describe who reviews/approves at this authority.
     */
    public function approvalStages(): HasMany
    {
        return $this->hasMany(AuthorityApprovalStage::class, 'authority_id')
            ->orderBy('stage_order');
    }

    /**
     * Active approval stages only.
     */
    public function activeApprovalStages(): HasMany
    {
        return $this->hasMany(AuthorityApprovalStage::class, 'authority_id')
            ->where('is_active', true)
            ->orderBy('stage_order');
    }

    /**
     * The approval route configured for this authority.
     *
     * IMPORTANT:
     * This is the approval workflow route.
     * parent_id is organizational hierarchy only and must not be used as an
     * approval destination.
     */
    public function approvalRoute(): HasOne
    {
        return $this->hasOne(AuthorityApprovalRoute::class, 'authority_id');
    }

    /**
     * The active approval route configured for this authority.
     */
    public function activeApprovalRoute(): HasOne
    {
        return $this->hasOne(AuthorityApprovalRoute::class, 'authority_id')
            ->where('is_active', true);
    }

    /**
     * Authorities whose approval routes point to this authority.
     */
    public function incomingApprovalRoutes(): HasMany
    {
        return $this->hasMany(
            AuthorityApprovalRoute::class,
            'destination_authority_id'
        )->where('destination_type', AuthorityApprovalRoute::DESTINATION_AUTHORITY);
    }

    // -----------------------------------------------------------------------
    // Helper Methods
    // -----------------------------------------------------------------------

    /**
     * دالة مساعدة للحصول على جميع الأحفاد (recursive)
     */
    public function getAllChildren()
    {
        return $this->children()->with('allChildren');
    }

    /**
     * دالة للتحقق مما إذا كانت الجهة لها أطفال
     */
    public function hasChildren(): bool
    {
        return $this->children()->exists();
    }

    /**
     * دالة للحصول على المسار الكامل
     */
    public function getFullPathAttribute(): string
    {
        $path = [];
        $current = $this;
        $visited = [];

        while ($current) {
            $currentId = (int) $current->id;

            if ($currentId > 0 && isset($visited[$currentId])) {
                throw new RuntimeException(
                    'تم اكتشاف دورة في الهيكل التنظيمي للجهات الخارجية.'
                );
            }

            if ($currentId > 0) {
                $visited[$currentId] = true;
            }

            $path[] = $current->safe_name;

            if (! $current->parent_id) {
                break;
            }

            $current = static::withoutGlobalScopes()
                ->find($current->parent_id);
        }

        return implode(' → ', array_reverse($path));
    }

    /**
     * Accessor for `name` attribute to maintain backward compatibility.
     * Returns the safe agency name.
     */
    public function getNameAttribute()
    {
        return $this->safe_name;
    }

    /**
     * Accessor للحصول على اسم آمن (لا يحتوي على مراجع إكسل)
     */
    public function getSafeNameAttribute(): string
    {
        $name = $this->agency_name ?? '';

        // إذا كان الاسم يبدأ بـ '='، نعتبره مرجع إكسل غير صالح
        if (strpos($name, '=') === 0) {
            // يمكنك تسجيل خطأ أو إرجاع اسم افتراضي
            // نُرجِع الاسم مع إزالة '=' إن أمكن، أو نرجِع "جهة غير محددة"
            // محاولة استخراج النص بعد '=' (قد يكون مرجع خلية)
            $cleaned = ltrim($name, '=');
            // إذا كان الاسم بعد '=' فارغاً أو رقماً فقط، نرجِع اسماً افتراضياً
            if (empty($cleaned) || is_numeric($cleaned)) {
                return 'جهة غير محددة (بيانات ملوثة)';
            }

            return $cleaned;
        }

        return $name;
    }

    /**
     * التحقق من صحة الاسم (لا يبدأ بـ '=' وليس فارغاً)
     */
    public function isNameValid(): bool
    {
        $name = $this->agency_name ?? '';

        return ! empty($name) && strpos($name, '=') !== 0;
    }

    // -----------------------------------------------------------------------
    // Scopes
    // -----------------------------------------------------------------------

    protected static function booted()
    {
        parent::booted();

        static::addGlobalScope('valid_names', function (Builder $builder) {
            $builder->whereNotNull('authorities.agency_name')
                ->where('authorities.agency_name', '!=', '')
                ->where('authorities.agency_name', 'NOT LIKE', '=%');
        });
    }

    /**
     * Scope لاستبعاد الجهات ذات الأسماء غير الصالحة (تبدأ بـ '=' أو فارغة)
     */
    public function scopeWithValidNames(Builder $query): Builder
    {
        return $query->whereNotNull('authorities.agency_name')
            ->where('authorities.agency_name', '!=', '')
            ->where('authorities.agency_name', 'NOT LIKE', '=%');
    }

    /**
     * Scope لعكس السابق: استبعاد الصالحة فقط (للاستخدام في التنظيف)
     */
    public function scopeWithoutValidNames(Builder $query): Builder
    {
        return $query->withoutGlobalScope('valid_names')->where(function ($q) {
            $q->whereNull('authorities.agency_name')
                ->orWhere('authorities.agency_name', '=', '')
                ->orWhere('authorities.agency_name', 'LIKE', '=%');
        });
    }

    /**
     * Scope للجهات التي يمكن للمستخدم إضافتها
     * يستخدم في نماذج الإنشاء والتعديل
     */
    public function scopeAddableToUser(Builder $query)
    {
        $user = auth()->user();

        if (! $user) {
            return $query->whereRaw('1 = 0');
        }

        // دائماً نطبق فلتر الأسماء الصالحة
        $query->withValidNames();

        if ($user->isAdmin()) {
            return $query;
        }

        if (method_exists($user, 'canAddAuthorities') && $user->canAddAuthorities()) {
            return $query;
        }

        if ($user->entity && $user->entity->authority_id) {
            $authorityId = $user->entity->authority_id;

            return $query->where(function ($q) use ($authorityId) {
                $q->where('id', $authorityId)
                    ->orWhere('parent_id', $authorityId);
            });
        }

        return $query->whereRaw('1 = 0');
    }

    /**
     * Scope للجهات التي يمكن للمستخدم رؤيتها
     */
    public function scopeVisibleToUser(Builder $query)
    {
        $user = auth()->user();

        if (! $user) {
            return $query->whereRaw('1 = 0');
        }

        // دائماً نطبق فلتر الأسماء الصالحة
        $query->withValidNames();

        if ($user->isAdmin()) {
            return $query;
        }

        if ($user->entity && $user->entity->authority_id) {
            $authorityId = $user->entity->authority_id;

            return $query->where(function ($q) use ($authorityId) {
                $q->where('id', $authorityId)
                    ->orWhere('parent_id', $authorityId)
                    ->orWhereIn('id', function ($subQuery) use ($authorityId) {
                        $subQuery->select('id')
                            ->from('authorities')
                            ->where('parent_id', $authorityId);
                    });
            });
        }

        return $query->whereRaw('1 = 0');
    }

    /**
     * Scope للجهات النشطة فقط
     */
    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    /**
     * Scope للجهات غير النشطة
     */
    public function scopeInactive(Builder $query): Builder
    {
        return $query->where('is_active', false);
    }

    /**
     * Scope للجهات الممولة
     */
    public function scopeFunded(Builder $query): Builder
    {
        return $query->where('is_funded', true);
    }

    /**
     * Scope للجهات غير الممولة
     */
    public function scopeUnfunded(Builder $query): Builder
    {
        return $query->where('is_funded', false);
    }

    /**
     * Scope للبحث في اسم الجهة (يبحث في الاسم الأصلي)
     */
    public function scopeSearch(Builder $query, string $searchTerm): Builder
    {
        return $query->where('agency_name', 'like', "%{$searchTerm}%");
    }

    /**
     * Scope للجهات التي ليس لها أب (الجذور)
     */
    public function scopeRoots(Builder $query): Builder
    {
        return $query->whereNull('parent_id');
    }

    /**
     * Scope للجهات التابعة لجهة معينة
     */
    public function scopeChildrenOf(Builder $query, int $parentId): Builder
    {
        return $query->where('parent_id', $parentId);
    }

    /**
     * Scope للجهات التي لها أطفال
     */
    public function scopeHasChildren(Builder $query): Builder
    {
        return $query->has('children');
    }

    /**
     * Scope للجهات التي ليس لها أطفال
     */
    public function scopeWithoutChildren(Builder $query): Builder
    {
        return $query->doesntHave('children');
    }

    /**
     * Scope للجهات حسب المحافظة
     */
    public function scopeInGovernorate(Builder $query, int $governorateId): Builder
    {
        return $query->where('governorate_id', $governorateId);
    }

    /**
     * Scope للجهات حسب المديرية
     */
    public function scopeInDirectorate(Builder $query, int $directorateId): Builder
    {
        return $query->where('directorate_id', $directorateId);
    }

    /**
     * Scope للجهات حسب نوع الكيان
     */
    public function scopeOfType(Builder $query, int $typeEntityId): Builder
    {
        return $query->where('type_entity_id', $typeEntityId);
    }

    /**
     * Scope للجهات حسب النطاق (داخلي/خارجي)
     */
    public function scopeWithEntityScope(Builder $query, string $scope): Builder
    {
        return $query->where('entity_scope', $scope);
    }

    // -----------------------------------------------------------------------
    // Helper Functions for Tree Operations
    // -----------------------------------------------------------------------

    /**
     * الحصول على جميع أسلاف الجهة (من الأعلى إلى الأسفل)
     */
    public function getAncestors(): Collection
    {
        $ancestors = collect();
        $currentId = $this->parent_id ? (int) $this->parent_id : null;
        $visited = [(int) $this->id => true];

        while ($currentId) {
            if (isset($visited[$currentId])) {
                throw new RuntimeException(
                    'تم اكتشاف دورة في الهيكل التنظيمي للجهات الخارجية.'
                );
            }

            $visited[$currentId] = true;

            $current = static::withoutGlobalScopes()->find($currentId);

            if (! $current) {
                break;
            }

            $ancestors->push($current);
            $currentId = $current->parent_id ? (int) $current->parent_id : null;
        }

        return $ancestors;
    }

    /**
     * الحصول على جميع أحفاد الجهة (بشكل متكرر)
     */
    public function getDescendants(): Collection
    {
        $ids = static::getAllDescendantIds((int) $this->id);

        if (empty($ids)) {
            return collect();
        }

        return static::withoutGlobalScopes()
            ->whereIn('id', $ids)
            ->get()
            ->sortBy(function (self $authority) use ($ids) {
                return array_search((int) $authority->id, $ids, true);
            })
            ->values();
    }

    /**
     * Return all organizational descendant IDs.
     *
     * This helper is for organizational visibility/tree operations only.
     * It must never be used to construct an approval route.
     */
    public static function getAllDescendantIds(int $authorityId): array
    {
        if ($authorityId <= 0) {
            return [];
        }

        $visited = [$authorityId => true];
        $toProcess = [$authorityId];
        $result = [];

        while (! empty($toProcess)) {
            $children = DB::table('authorities')
                ->whereIn('parent_id', $toProcess)
                ->pluck('id')
                ->map(fn ($id) => (int) $id)
                ->toArray();

            if (empty($children)) {
                break;
            }

            $next = [];

            foreach ($children as $childId) {
                if (isset($visited[$childId])) {
                    continue;
                }

                $visited[$childId] = true;
                $result[] = $childId;
                $next[] = $childId;
            }

            $toProcess = $next;
        }

        return array_values(array_unique($result));
    }

    /**
     * Return this authority plus all organizational descendants.
     *
     * Again, this is organizational hierarchy only.
     */
    public static function getSelfAndDescendantIds(int $authorityId): array
    {
        if ($authorityId <= 0) {
            return [];
        }

        return array_values(array_unique(array_merge(
            [$authorityId],
            static::getAllDescendantIds($authorityId)
        )));
    }

    /**
     * التحقق مما إذا كانت الجهة لها أحفاد
     */
    public function hasDescendants(): bool
    {
        return $this->getDescendants()->isNotEmpty();
    }

    /**
     * الحصول على مستوى الجهة في الشجرة (0 للجذور)
     */
    public function getLevel(): int
    {
        $level = 0;
        $currentId = $this->parent_id ? (int) $this->parent_id : null;
        $visited = [(int) $this->id => true];

        while ($currentId) {
            if (isset($visited[$currentId])) {
                throw new RuntimeException(
                    'تم اكتشاف دورة في الهيكل التنظيمي للجهات الخارجية.'
                );
            }

            $visited[$currentId] = true;
            $level++;

            $currentId = DB::table('authorities')
                ->where('id', $currentId)
                ->value('parent_id');

            $currentId = $currentId ? (int) $currentId : null;
        }

        return $level;
    }

    /**
     * الحصول على شجرة الجهة كاملة (للعرض)
     */
    public function getTree(array $visited = []): array
    {
        $currentId = (int) $this->id;

        if (isset($visited[$currentId])) {
            throw new RuntimeException(
                'تم اكتشاف دورة في الهيكل التنظيمي للجهات الخارجية.'
            );
        }

        $visited[$currentId] = true;

        $children = static::withoutGlobalScopes()
            ->where('parent_id', $this->id)
            ->orderBy('agency_name')
            ->get();

        return [
            'id' => $this->id,
            'name' => $this->safe_name,
            'children' => $children
                ->map(fn (self $child) => $child->getTree($visited))
                ->toArray(),
        ];
    }

    /**
     * الحصول على مسار الجهة كمصفوفة
     */
    public function getPathArray(): array
    {
        $path = [];
        $current = $this;
        $visited = [];

        while ($current) {
            $currentId = (int) $current->id;

            if ($currentId > 0 && isset($visited[$currentId])) {
                throw new RuntimeException(
                    'تم اكتشاف دورة في الهيكل التنظيمي للجهات الخارجية.'
                );
            }

            if ($currentId > 0) {
                $visited[$currentId] = true;
            }

            $path[] = [
                'id' => $current->id,
                'name' => $current->safe_name,
            ];

            if (! $current->parent_id) {
                break;
            }

            $current = static::withoutGlobalScopes()
                ->find($current->parent_id);
        }

        return array_reverse($path);
    }

    // -----------------------------------------------------------------------
    // Approval Route Helpers
    // -----------------------------------------------------------------------

    /**
     * Get the active approval route for this authority.
     *
     * Approval routing MUST come from authority_approval_routes and never from
     * authorities.parent_id.
     */
    public function getConfiguredApprovalRoute(): ?AuthorityApprovalRoute
    {
        $routes = AuthorityApprovalRoute::withoutGlobalScopes()
            ->where('authority_id', $this->id)
            ->where('is_active', true)
            ->orderBy('id')
            ->limit(2)
            ->get();

        if ($routes->count() > 1) {
            throw new RuntimeException(
                "يوجد أكثر من مسار موافقة فعال للجهة الخارجية [{$this->safe_name}]."
            );
        }

        return $routes->first();
    }

    /**
     * Validate that this authority has a complete approval configuration.
     *
     * Requirements:
     * - Authority must be active.
     * - It must have at least one active configured stage.
     * - Every active stage must have a valid external responsible user.
     * - It must have exactly one active approval route.
     * - The full route must eventually reach the Ministry.
     */
    public function approvalConfigurationError(): ?string
    {
        if (! $this->is_active) {
            return 'الجهة الخارجية غير مفعلة.';
        }

        $stages = AuthorityApprovalStage::withoutGlobalScopes()
            ->where('authority_id', $this->id)
            ->where('is_active', true)
            ->orderBy('stage_order')
            ->get();

        if ($stages->isEmpty()) {
            return 'لا توجد مراحل موافقة مفعلة لهذه الجهة الخارجية.';
        }

        foreach ($stages as $stage) {
            $error = method_exists($stage, 'validationError')
                ? $stage->validationError()
                : ($stage->hasValidResponsibleUser()
                    ? null
                    : 'المستخدم المسؤول عن المرحلة غير صالح.');

            if ($error !== null) {
                $stageName = $stage->stageEnum()?->label() ?? $stage->stage;

                return "مرحلة [{$stageName}] غير صالحة: {$error}";
            }
        }

        try {
            $route = $this->getConfiguredApprovalRoute();
        } catch (RuntimeException $e) {
            return $e->getMessage();
        }

        if (! $route) {
            return 'لا يوجد مسار موافقة فعال لهذه الجهة الخارجية.';
        }

        if (method_exists($route, 'validateFullChain')) {
            $validation = $route->validateFullChain();

            if (! ($validation['is_valid'] ?? false)) {
                return $validation['error'] ?? 'مسار الموافقة الخارجي غير صالح.';
            }
        } elseif (method_exists($route, 'isValidRoute') && ! $route->isValidRoute()) {
            return $route->validationError() ?? 'مسار الموافقة الخارجي غير صالح.';
        }

        return null;
    }

    /**
     * Whether this authority is ready for ApprovalChainBuilder.
     */
    public function isReadyForApprovalChain(): bool
    {
        return $this->approvalConfigurationError() === null;
    }

    /**
     * Return the external approval-authority chain until the Ministry.
     *
     * This returns Authority models only. The Ministry is an InternalEntity and
     * therefore is not represented as an Authority in the returned collection.
     */
    public function getApprovalAuthorityChain(): Collection
    {
        $chain = collect();
        $visited = [];
        $current = $this;

        while ($current) {
            $currentId = (int) $current->id;

            if (isset($visited[$currentId])) {
                throw new RuntimeException(
                    'تم اكتشاف مسار موافقة دائري بين الجهات الخارجية.'
                );
            }

            $visited[$currentId] = true;
            $chain->push($current);

            $route = $current->getConfiguredApprovalRoute();

            if (! $route) {
                throw new RuntimeException(
                    "لا يوجد مسار موافقة فعال للجهة الخارجية [{$current->safe_name}]."
                );
            }

            $routeError = method_exists($route, 'validationError')
                ? $route->validationError()
                : null;

            if ($routeError !== null) {
                throw new RuntimeException($routeError);
            }

            if (
                method_exists($route, 'goesToMinistry')
                ? $route->goesToMinistry()
                : $route->destination_type === 'ministry'
            ) {
                return $chain;
            }

            $nextAuthorityId = method_exists($route, 'getNextAuthorityId')
                ? $route->getNextAuthorityId()
                : (int) $route->destination_authority_id;

            if (! $nextAuthorityId) {
                throw new RuntimeException(
                    'مسار الموافقة يشير إلى جهة خارجية دون تحديد الجهة التالية.'
                );
            }

            $current = static::withoutGlobalScopes()->find($nextAuthorityId);

            if (! $current) {
                throw new RuntimeException(
                    "الجهة الخارجية التالية في مسار الموافقة رقم [{$nextAuthorityId}] غير موجودة."
                );
            }
        }

        throw new RuntimeException(
            'تعذر إكمال مسار الموافقة الخارجي حتى الوزارة.'
        );
    }

    // -----------------------------------------------------------------------
    // Additional Scopes for Bulk Operations
    // -----------------------------------------------------------------------

    /**
     * Scope للجهات التي يمكن تعديلها بشكل جماعي
     */
    public function scopeBulkEditable(Builder $query): Builder
    {
        $user = auth()->user();

        if (! $user) {
            return $query->whereRaw('1 = 0');
        }

        // تطبيق فلتر الأسماء الصالحة
        $query->withValidNames();

        if ($user->isAdmin()) {
            return $query;
        }

        return $query->whereRaw('1 = 0');
    }

    /**
     * Scope للجهات التي يمكن حذفها
     */
    public function scopeDeletable(Builder $query): Builder
    {
        $user = auth()->user();

        if (! $user) {
            return $query->whereRaw('1 = 0');
        }

        // تطبيق فلتر الأسماء الصالحة
        $query->withValidNames();

        if ($user->isAdmin()) {
            return $query;
        }

        return $query->whereRaw('1 = 0');
    }

    /**
     * Scope لتنظيف البيانات: استرجاع الجهات ذات الأسماء غير الصالحة لتحديثها
     */
    public function scopeInvalidNames(Builder $query)
    {
        return $query->withoutValidNames();
    }
}

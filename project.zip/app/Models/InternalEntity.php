<?php

namespace App\Models;

use App\Traits\Auditable;
use App\Traits\HasActiveScope;
use App\Traits\HasCreatorTracking;
use App\Traits\HasDomainScope;
use App\Traits\HasModelVisibility;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class InternalEntity extends Model
{
    use Auditable, HasActiveScope, HasCreatorTracking, HasDomainScope, HasFactory, HasModelVisibility {
        HasModelVisibility::scopeVisibleToUser insteadof HasDomainScope;
    }

    protected $table = 'internal_entities';

    protected $fillable = [
        'status',
        'name',
        'entity_type',
        'entity_code',
        'parent_id',
        'authority_id',
        'governorate_id',
        'directorate_id',
        'is_active',
        'creator_username',
        'creator_entity_id',
        'erpnext_id',
        'erpnext_type',
        'erpnext_parent_id',
        'is_ministry_root',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'is_ministry_root' => 'boolean',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    // ============================================
    // العلاقات
    // ============================================
    public function parent()
    {
        return $this->belongsTo(InternalEntity::class, 'parent_id');
    }

    public function authority()
    {
        return $this->belongsTo(Authority::class, 'authority_id');
    }

    public function governorate()
    {
        return $this->belongsTo(Governorate::class, 'governorate_id');
    }

    public function directorate()
    {
        return $this->belongsTo(Directorate::class, 'directorate_id');
    }

    public function children()
    {
        return $this->hasMany(InternalEntity::class, 'parent_id');
    }

    /**
     * The configured approval stages for this entity.
     * Each row represents an ENABLED stage with its responsible user.
     */
    public function approvalStages(): HasMany
    {
        return $this->hasMany(EntityApprovalStage::class, 'entity_id')
            ->orderBy('stage_order');
    }

    /**
     * Active configured approval stages only.
     *
     * This is the set that may be used while generating an approval chain.
     */
    public function activeApprovalStages(): HasMany
    {
        return $this->hasMany(EntityApprovalStage::class, 'entity_id')
            ->where('is_active', true)
            ->orderBy('stage_order');
    }

    /**
     * Get all children (descendants) of this entity recursively
     * Uses DB directly to avoid lazy loading issues
     */
    public function getAllChildren()
    {
        $ids = static::getAllDescendantIds($this->id);

        if (empty($ids)) {
            return collect();
        }

        // Remove the current entity from the list if present
        $ids = array_diff($ids, [$this->id]);

        if (empty($ids)) {
            return collect();
        }

        return static::whereIn('id', $ids)->get();
    }

    /**
     * Get all descendant IDs for a given parent ID recursively
     * Uses DB directly to avoid lazy loading issues
     */
    public static function getAllDescendantIds($parentId): array
    {
        if (! $parentId) {
            return [];
        }

        $toProcess = [(int) $parentId];
        $allDescendants = [];
        $visited = [(int) $parentId => true];

        while (! empty($toProcess)) {
            $children = DB::table('internal_entities')
                ->whereIn('parent_id', $toProcess)
                ->pluck('id')
                ->map(fn ($id) => (int) $id)
                ->toArray();

            if (empty($children)) {
                break;
            }

            $newToProcess = [];
            foreach ($children as $child) {
                if (! isset($visited[$child])) {
                    $visited[$child] = true;
                    $allDescendants[] = $child;
                    $newToProcess[] = $child;
                }
            }

            $toProcess = $newToProcess;
        }

        return array_unique($allDescendants);
    }

    /**
     * جلب جميع معرفات الأطفال بشكل متكرر — يستخدم DB مباشرة لتجاوز DomainScope
     */
    public static function getAllChildrenIds($parentId): array
    {
        return static::getAllDescendantIds($parentId);
    }

    /**
     * Return the entity itself plus all descendants.
     *
     * Useful for authorization/visibility code that needs an inclusive scope.
     */
    public static function getSelfAndDescendantIds($entityId): array
    {
        $entityId = (int) $entityId;

        if ($entityId <= 0) {
            return [];
        }

        return array_values(array_unique(array_merge(
            [$entityId],
            static::getAllDescendantIds($entityId)
        )));
    }

    /**
     * جلب جميع معرفات الأباء بشكل متكرر — يستخدم DB مباشرة لتجاوز DomainScope
     */
    public static function getAllParentIds(int $entityId): array
    {
        $ids = [];
        $currentId = $entityId;
        $visited = [(int) $entityId => true];

        while (true) {
            $parent = DB::table('internal_entities')
                ->where('id', $currentId)
                ->value('parent_id');

            if (! $parent) {
                break;
            }

            $parentId = (int) $parent;
            if (isset($visited[$parentId])) {
                break; // Prevent infinite loop due to circular reference
            }

            $ids[] = $parentId;
            $visited[$parentId] = true;
            $currentId = $parentId;
        }

        return $ids;
    }

    /**
     * جلب كل الجهات في محافظة — يستخدم DB مباشرة لتجاوز DomainScope
     */
    public static function getAllByGovernorate($governorateId): array
    {
        static $govCache = [];
        $cacheKey = (int) $governorateId;

        if (isset($govCache[$cacheKey])) {
            return $govCache[$cacheKey];
        }

        return $govCache[$cacheKey] = DB::table('internal_entities')
            ->where('governorate_id', $governorateId)
            ->pluck('id')
            ->map(fn ($id) => (int) $id)
            ->toArray();
    }

    /**
     * جلب كل الجهات في مديرية — يستخدم DB مباشرة لتجاوز DomainScope
     */
    public static function getAllByDirectorate($directorateId): array
    {
        static $dirCache = [];
        $cacheKey = (int) $directorateId;

        if (isset($dirCache[$cacheKey])) {
            return $dirCache[$cacheKey];
        }

        return $dirCache[$cacheKey] = DB::table('internal_entities')
            ->where('directorate_id', $directorateId)
            ->pluck('id')
            ->map(fn ($id) => (int) $id)
            ->toArray();
    }

    public function users()
    {
        return $this->hasMany(User::class, 'entity_id');
    }

    public function responsibilities()
    {
        return $this->hasMany(EntityResponsibility::class, 'internal_entity_id');
    }

    public function sentCorrespondences()
    {
        return $this->hasMany(Correspondence::class, 'sender_entity_id');
    }

    public function receivedCorrespondences()
    {
        return $this->hasMany(Correspondence::class, 'recipient_entity_id');
    }

    public function memoirs()
    {
        return $this->hasMany(Memoir::class, 'entity_id');
    }

    // ============================================
    // Scopes
    // ============================================
    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    public function scopeIsMinistryRoot(Builder $query): Builder
    {
        return $query->where('is_ministry_root', true);
    }

    /**
     * Return the single configured Ministry Root.
     *
     * IMPORTANT:
     * parent_id = null does NOT mean Ministry Root.
     * The only source of truth is is_ministry_root = true.
     *
     * If more than one Ministry Root is configured, fail loudly because
     * approval chains would otherwise be ambiguous.
     */
    public static function getMinistryRoot(): ?self
    {
        $roots = static::withoutGlobalScopes()
            ->where('is_ministry_root', true)
            ->orderBy('id')
            ->limit(2)
            ->get();

        if ($roots->count() > 1) {
            throw new RuntimeException(
                'يوجد أكثر من كيان داخلي محدد كجذر للوزارة. يجب أن يكون هناك جذر وزارة واحد فقط.'
            );
        }

        return $roots->first();
    }

    /**
     * Return the Ministry Root and fail if it has not been configured.
     */
    public static function requireMinistryRoot(): self
    {
        $root = static::getMinistryRoot();

        if (! $root) {
            throw new RuntimeException(
                'لم يتم تحديد الجهة الجذر للوزارة (is_ministry_root = true).'
            );
        }

        return $root;
    }

    /**
     * Whether this entity is the configured Ministry Root.
     */
    public function isMinistryRoot(): bool
    {
        return (bool) $this->is_ministry_root;
    }

    public function scopeParents($query)
    {
        return $query->whereNull('parent_id');
    }

    /**
     * فلترة حسب governorate أو directorate
     */
    public function scopeByLocation($query, $governorateId = null, $directorateId = null)
    {
        if ($governorateId) {
            $query->where('governorate_id', $governorateId);
        }
        if ($directorateId) {
            $query->where('directorate_id', $directorateId);
        }

        return $query;
    }

    // ============================================
    // Methods: Hierarchy & Approval
    // ============================================
    public function getHierarchyPath(): string
    {
        $path = [];
        $current = $this;
        $visited = [];

        while ($current) {
            $currentId = (int) $current->id;

            if ($currentId > 0 && isset($visited[$currentId])) {
                throw new RuntimeException(
                    'تم اكتشاف دورة في التسلسل الإداري للجهات الداخلية.'
                );
            }

            if ($currentId > 0) {
                $visited[$currentId] = true;
            }

            array_unshift($path, $current->name);

            if (! $current->parent_id) {
                break;
            }

            $current = static::withoutGlobalScopes()->find($current->parent_id);
        }

        return implode(' > ', $path);
    }

    public function getFullNameAttribute(): string
    {
        return $this->getHierarchyPath();
    }

    /**
     * Build the internal organizational chain from this entity upward.
     *
     * The chain is valid for approval routing only when it reaches the entity
     * explicitly marked is_ministry_root = true.
     *
     * Organizational hierarchy remains internal-only and must never be mixed
     * with Authority approval routes.
     */
    public function getApprovalChainToRoot(): Collection
    {
        $chain = collect();
        $current = $this;
        $visited = [];
        $ministryRoot = static::requireMinistryRoot();

        while ($current) {
            $currentId = (int) $current->id;

            if (isset($visited[$currentId])) {
                throw new RuntimeException(
                    'تم اكتشاف دورة في التسلسل الإداري للجهات الداخلية.'
                );
            }

            $visited[$currentId] = true;
            $chain->push($current);

            if ($currentId === (int) $ministryRoot->id) {
                return $chain;
            }

            if (! $current->parent_id) {
                break;
            }

            $current = static::withoutGlobalScopes()->find($current->parent_id);
        }

        throw new RuntimeException(
            "التسلسل الإداري للجهة [{$this->name}] لا يصل إلى جذر الوزارة المحدد."
        );
    }

    public function getParentChain(): Collection
    {
        $parents = collect();
        $currentId = $this->parent_id ? (int) $this->parent_id : null;
        $visited = [(int) $this->id => true];

        while ($currentId) {
            if (isset($visited[$currentId])) {
                throw new RuntimeException(
                    'تم اكتشاف دورة في التسلسل الإداري للجهات الداخلية.'
                );
            }

            $visited[$currentId] = true;

            $current = static::withoutGlobalScopes()->find($currentId);

            if (! $current) {
                break;
            }

            $parents->push($current);
            $currentId = $current->parent_id ? (int) $current->parent_id : null;
        }

        return $parents;
    }

    /**
     * Structural hierarchy root only.
     *
     * This does NOT mean Ministry Root.
     * Approval logic must use isMinistryRoot().
     */
    public function isRootEntity(): bool
    {
        return is_null($this->parent_id);
    }

    public function getHierarchyLevel(): int
    {
        $level = 0;
        $currentId = $this->parent_id ? (int) $this->parent_id : null;
        $visited = [(int) $this->id => true];

        while ($currentId) {
            if (isset($visited[$currentId])) {
                throw new RuntimeException(
                    'تم اكتشاف دورة في التسلسل الإداري للجهات الداخلية.'
                );
            }

            $visited[$currentId] = true;
            $level++;

            $currentId = DB::table('internal_entities')
                ->where('id', $currentId)
                ->value('parent_id');

            $currentId = $currentId ? (int) $currentId : null;
        }

        return $level;
    }

    /**
     * Validate whether this entity can participate in an internal approval chain.
     */
    public function approvalConfigurationError(): ?string
    {
        if (! $this->is_active) {
            return 'الجهة الداخلية غير مفعلة.';
        }

        try {
            $this->getApprovalChainToRoot();
        } catch (RuntimeException $e) {
            return $e->getMessage();
        }

        $stages = $this->activeApprovalStages()->get();

        if ($stages->isEmpty()) {
            return 'لا توجد مراحل موافقة مفعلة لهذه الجهة.';
        }

        foreach ($stages as $stage) {
            if (! $stage->hasValidResponsibleUser()) {
                $stageName = $stage->stageEnum()?->label() ?? $stage->stage;

                return "المستخدم المسؤول عن مرحلة [{$stageName}] غير صالح.";
            }
        }

        return null;
    }

    /**
     * Whether this entity is ready to be used by ApprovalChainBuilder.
     */
    public function isReadyForApprovalChain(): bool
    {
        return $this->approvalConfigurationError() === null;
    }

    /**
     * Generate or return entity code
     */
    public function getEntityCode(): string
    {
        if (empty($this->entity_code)) {
            $words = explode(' ', trim($this->name));
            $code = count($words) >= 2 ? substr($words[0], 0, 1).substr($words[1], 0, 1) : substr($this->name, 0, 2);
            $code = strtoupper(preg_replace('/[^A-Z0-9]/', 'X', $code));
            $code = str_pad($code, 2, 'X');
            $this->entity_code = $code;
            $this->save();
        }

        return $this->entity_code;
    }

    public function setEntityCode(string $code): void
    {
        $this->entity_code = strtoupper(substr(preg_replace('/[^A-Za-z0-9]/', '', $code), 0, 2));
        $this->save();
    }

    /**
     * Find governorate-level ancestor
     */
    private function findGovernorateAncestor(InternalEntity $entity): ?InternalEntity
    {
        if (is_null($entity->parent_id)) {
            return $entity;
        }

        $current = $entity;
        while ($current->parent && ! is_null($current->parent->parent_id)) {
            $current = $current->parent;
        }

        return $current->parent_id ? $current : $entity;
    }

    public static function getEntitiesForUserGovernorate(User $user): array
    {
        $entityIds = [];

        foreach ($user->geographicScopes as $scope) {
            if ($scope->governorate_id) {
                $entityIds = array_merge(
                    $entityIds,
                    static::getAllByGovernorate($scope->governorate_id)
                );
            }
        }

        return array_values(array_unique($entityIds));
    }
}

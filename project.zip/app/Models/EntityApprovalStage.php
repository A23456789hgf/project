 
<?php

namespace App\Models;

use App\Enums\EntityResponsibilityType;
use App\Enums\UserResponsibilityType;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * إعداد مرحلة موافقة لجهة داخلية.
 *
 * كل سجل يحدد:
 * - الجهة الداخلية التي تنتمي إليها المرحلة.
 * - نوع المرحلة.
 * - ترتيب المرحلة.
 * - المستخدم المسؤول عنها.
 * - حالة تفعيل المرحلة.
 *
 * مهم:
 * هذا الموديل خاص بـ InternalEntity فقط.
 * ولا يجوز استخدام Authority ID داخل entity_id.
 */
class EntityApprovalStage extends Model
{
    protected $fillable = [
        'entity_id',
        'stage',
        'is_active',
        'stage_order',
        'responsible_user_id',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'entity_id' => 'integer',
        'stage_order' => 'integer',
        'responsible_user_id' => 'integer',
        'is_active' => 'boolean',
        'created_by' => 'integer',
        'updated_by' => 'integer',
    ];

    /*
    |--------------------------------------------------------------------------
    | Relationships
    |--------------------------------------------------------------------------
    */

    /**
     * الجهة الداخلية صاحبة المرحلة.
     */
    public function entity(): BelongsTo
    {
        return $this->belongsTo(
            InternalEntity::class,
            'entity_id'
        );
    }

    /**
     * المستخدم المسؤول صراحة عن تنفيذ المرحلة.
     *
     * نستخدم withoutGlobalScopes لأن التحقق من إعدادات
     * الموافقات يجب أن يصل للمستخدم المحدد مباشرة.
     */
    public function responsibleUser(): BelongsTo
    {
        return $this->belongsTo(
            User::class,
            'responsible_user_id'
        )->withoutGlobalScopes();
    }

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(
            User::class,
            'created_by'
        )->withoutGlobalScopes();
    }

    public function updatedBy(): BelongsTo
    {
        return $this->belongsTo(
            User::class,
            'updated_by'
        )->withoutGlobalScopes();
    }

    /*
    |--------------------------------------------------------------------------
    | Scopes
    |--------------------------------------------------------------------------
    */

    /**
     * ترتيب المراحل حسب stage_order.
     */
    public function scopeOrdered(Builder $query): Builder
    {
        return $query->orderBy('stage_order');
    }

    /**
     * المراحل المفعلة فقط.
     */
    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    /**
     * مراحل جهة داخلية محددة.
     */
    public function scopeForEntity(
        Builder $query,
        int $entityId
    ): Builder {
        return $query->where(
            'entity_id',
            $entityId
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Stage Helpers
    |--------------------------------------------------------------------------
    */

    /**
     * تحويل stage إلى Enum.
     */
    public function stageEnum(): ?EntityResponsibilityType
    {
        if (empty($this->stage)) {
            return null;
        }

        return EntityResponsibilityType::tryFrom(
            (string) $this->stage
        );
    }

    /**
     * نوع مسؤولية المستخدم المطلوبة لهذه المرحلة.
     *
     * TECHNICAL_REVIEW
     *      => TECHNICAL
     *
     * FINANCIAL_REVIEW
     *      => FINANCIAL
     *
     * APPROVAL
     *      => ENTITY_APPROVER
     */
    public function requiredUserResponsibility(): ?UserResponsibilityType
    {
        $stage = $this->stageEnum();

        if (! $stage) {
            return null;
        }

        return UserResponsibilityType::forStage($stage);
    }

    /**
     * Phase المستخدمة داخل ProjectApproval.
     */
    public function phaseCode(): ?string
    {
        return $this->stageEnum()?->phaseCode();
    }

    /**
     * الترتيب الرسمي لنوع المرحلة.
     */
    public function expectedStageOrder(): ?int
    {
        return $this->stageEnum()?->stageOrder();
    }

    /*
    |--------------------------------------------------------------------------
    | Responsible User Validation
    |--------------------------------------------------------------------------
    */

    /**
     * التحقق الكامل من المستخدم المسؤول.
     *
     * يجب أن يكون:
     *
     * 1. موجوداً.
     * 2. Active.
     * 3. organization_type = internal.
     * 4. entity_id الخاص به يساوي entity_id المرحلة.
     * 5. authority_id = NULL.
     * 6. مسؤوليته متوافقة مع نوع المرحلة.
     */
    public function hasValidResponsibleUser(): bool
    {
        if (
            empty($this->entity_id)
            || empty($this->responsible_user_id)
        ) {
            return false;
        }

        $stage = $this->stageEnum();

        if (! $stage) {
            return false;
        }

        $requiredResponsibility =
            UserResponsibilityType::forStage($stage);

        $user = $this->responsibleUser;

        if (! $user) {
            return false;
        }

        /*
         * يجب أن يكون المستخدم نشطاً.
         */
        if ($user->status !== 'Active') {
            return false;
        }

        /*
         * هذه المرحلة خاصة بجهة داخلية حصراً.
         */
        if ($user->organization_type !== 'internal') {
            return false;
        }

        /*
         * المستخدم الداخلي يجب ألا يحمل Authority ID.
         */
        if (! empty($user->authority_id)) {
            return false;
        }

        /*
         * المستخدم يجب أن ينتمي لنفس InternalEntity.
         */
        if (
            (int) $user->entity_id !==
            (int) $this->entity_id
        ) {
            return false;
        }

        /*
         * التحقق من المسؤولية.
         *
         * قد تكون responsibility محولة إلى Enum
         * بواسطة casts داخل User model.
         */
        $userResponsibility = $user->responsibility;

        if (! $userResponsibility) {
            return false;
        }

        if ($userResponsibility instanceof UserResponsibilityType) {
            return $userResponsibility === $requiredResponsibility;
        }

        $responsibilityEnum =
            UserResponsibilityType::tryFrom(
                (string) $userResponsibility
            );

        return $responsibilityEnum === $requiredResponsibility;
    }

    /**
     * هل المرحلة جاهزة للاستخدام عند بناء Approval Chain؟
     */
    public function isReadyForApprovalChain(): bool
    {
        return $this->is_active
            && $this->stageEnum() !== null
            && $this->hasValidResponsibleUser();
    }

    /**
     * إرجاع سبب عدم صلاحية إعداد المرحلة.
     *
     * مفيد في:
     * - ApprovalChainBuilder
     * - شاشة إعداد المراحل
     * - فحص الإعدادات قبل تقديم المشروع
     */
    public function validationError(): ?string
    {
        if (! $this->is_active) {
            return 'المرحلة غير مفعلة.';
        }

        if (empty($this->entity_id)) {
            return 'المرحلة غير مرتبطة بجهة داخلية.';
        }

        $stage = $this->stageEnum();

        if (! $stage) {
            return 'نوع مرحلة الموافقة غير صالح.';
        }

        if (empty($this->responsible_user_id)) {
            return 'لم يتم تحديد المستخدم المسؤول عن المرحلة.';
        }

        $user = $this->responsibleUser;

        if (! $user) {
            return 'المستخدم المسؤول عن المرحلة غير موجود.';
        }

        if ($user->status !== 'Active') {
            return 'المستخدم المسؤول عن المرحلة غير نشط.';
        }

        if ($user->organization_type !== 'internal') {
            return 'المستخدم المسؤول ليس مستخدماً تابعاً لجهة داخلية.';
        }

        if (! empty($user->authority_id)) {
            return 'المستخدم المسؤول مرتبط بجهة خارجية ولا يمكن استخدامه لمرحلة جهة داخلية.';
        }

        if (
            (int) $user->entity_id !==
            (int) $this->entity_id
        ) {
            return 'المستخدم المسؤول لا ينتمي إلى الجهة الداخلية الخاصة بهذه المرحلة.';
        }

        $requiredResponsibility =
            UserResponsibilityType::forStage($stage);

        $userResponsibility = $user->responsibility;

        if (! $userResponsibility) {
            return 'لم يتم تحديد مسؤولية المستخدم المسؤول عن المرحلة.';
        }

        if ($userResponsibility instanceof UserResponsibilityType) {
            if ($userResponsibility !== $requiredResponsibility) {
                return 'مسؤولية المستخدم لا تتوافق مع نوع مرحلة الموافقة.';
            }
        } else {
            $responsibilityEnum =
                UserResponsibilityType::tryFrom(
                    (string) $userResponsibility
                );

            if ($responsibilityEnum !== $requiredResponsibility) {
                return 'مسؤولية المستخدم لا تتوافق مع نوع مرحلة الموافقة.';
            }
        }

        return null;
    }
}
 
